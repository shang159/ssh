package structures.basic;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;

import com.fasterxml.jackson.databind.introspect.TypeResolutionContext.Basic;

import akka.actor.ActorRef;
import commands.BasicCommands;
import structures.GameState;
import structures.InnerEventListener.InnerEventType;
import structures.basic.HandCard.AbilityType;
import utils.BasicObjectBuilders;
import utils.StaticConfFiles;

/**this class will implement unit card abilities,
 * featured attack priority, health/attack dealing
 * */
public class OperatableUnit extends Unit {

	protected int health;
	protected int attack;
	private Player player;
	private Card innerCard;
	protected int moveChance;
	protected int attackChance;
	protected AttackPriority priorityLevel;
	
	enum AttackPriority {
		NORMAL,
		PROVOKE(9),
		AVATAR(8);
		
		int priorityLevel;
		private AttackPriority() {
			this.priorityLevel = 1;
		}
		
		private AttackPriority(int i) {
			this.priorityLevel = i;
		}
		
		public int getPriorityLevel() {
			return this.priorityLevel;
		}
	}
	
	private final int MAX_HEALTH = 20;
	private final int MAX_ATTACK = 20;
	private final int MAX_MOVE_CHANCE = 1;
	private final int MAX_ATTACK_CHANCE = 1;
	
	public OperatableUnit() {
		super();
		this.health = 0;
		this.attack = 0;
		this.player = null;
		this.innerCard = null;
		this.moveChance = MAX_ATTACK_CHANCE;
		this.attackChance = MAX_MOVE_CHANCE;
		this.priorityLevel = AttackPriority.NORMAL;
	}
	

	// ## ==== health-related methods ====
	public int getHealth() {
		return this.health;
	}
	
	public int getMaxHealth() {
		return this.innerCard != null ? this.innerCard.getBigCard().getHealth() : MAX_HEALTH;
	}

	public void setHealth(int health) {
		this.health = health;
	}

	public boolean isHealthy() {
		return this.health > 0 ? true : false;
	}

	public void gainHealth(ActorRef out, GameState gameState, int deltaHealth) {
		this.playBuffedAnimation(out, gameState);
		
		if (((HandCard) gameState.whoseTurn().getCardOnHold()).getCardConfPath().equals(StaticConfFiles.c_pureblade_enforcer)
				|| ((HandCard) gameState.whoseTurn().getCardOnHold()).getCardConfPath().equals(StaticConfFiles.c_staff_of_ykir)) {
			
			// not capped buff
			setHealth(getHealth() + deltaHealth);
		} else {
			
			// capped healing
			setHealth( getHealth() + deltaHealth <= getMaxHealth() ? (getHealth() + deltaHealth) : getMaxHealth() );
		}
		
		BasicCommands.setUnitHealth(out, this, getHealth());
	}

	// ## ==== attack-related methods ====
	public int getAttack() {
		return this.attack;
	}
	
	public int getMaxAttack() {
		return this.innerCard != null ? this.innerCard.getBigCard().getAttack() : MAX_ATTACK;
	}

	public void setAttack(int attack) {
		this.attack = attack;
	}
	
	public void gainAttack(ActorRef out, GameState gameState, int deltaAttack) {
		this.playBuffedAnimation(out, gameState);
		setAttack(this.attack + deltaAttack);
		BasicCommands.setUnitAttack(out, this, this.attack);
	}
	
	
	public void gainBuff(ActorRef out, GameState gameState, int deltaAttack, int deltaHealth) {
		this.playBuffedAnimation(out, gameState);
		
		setAttack(getAttack() + deltaAttack);
		setHealth(getHealth() + deltaHealth);
		BasicCommands.setUnitAttack(out, this, getAttack());
		BasicCommands.setUnitHealth(out, this, getHealth());
		
	}
	
	private void playBuffedAnimation(ActorRef out, GameState gameState) {
		EffectAnimation effect = BasicObjectBuilders.loadEffect(StaticConfFiles.f1_buff);
		BasicCommands.playEffectAnimation(out, effect, gameState.getCell(this.getRow(), this.getCol()).getBottomTile());
		try {Thread.sleep(1000);} catch (Exception e) {e.printStackTrace();}
	}
	
	public AttackPriority getAttackPriority() {
		return this.priorityLevel;
	}
	
	// ## ==== move & attack related methods ====
	public boolean hasMoveChance() {
		return moveChance > 0 ? true : false;
	}
	
	public boolean hasAttackChance() {
		return attackChance > 0 ? true : false;
	}
	
	public int getRemainedMoveChance() {
		return this.moveChance;
	}
	
	public int getRemainedAttackChance() {
		return this.attackChance;
	}
	
	public void movePerformed() {
		if (this.hasMoveChance()) --moveChance;
	}
	
	public void attackPerformed() {
		if (this.hasAttackChance()) --attackChance;
		
		// ## attack foreits its move unless its ability is attack-twice
		if (this.hasMoveChance() && !this.hasAttackChance())
			this.movePerformed();
	}
	
	public void regainChance() {
		this.regainMoveChance();
		this.regainAttackChance();
	}
	
	private void regainMoveChance() {
		this.moveChance = MAX_MOVE_CHANCE;
	}
	
	// Assignee: the attack-twice is implemented by @Yingbo Ge and @Yueyue Liu, together with the helper methods.
	// ## tested
	private void regainAttackChance() {
		
		if (this instanceof AvatarUnit) {
			
			this.attackChance = MAX_ATTACK_CHANCE;
		} else {
			
			if (this.getCardConfPath().equals(StaticConfFiles.c_azurite_lion)
					|| this.getCardConfPath().equals(StaticConfFiles.c_serpenti)) {
				this.attackChance = MAX_ATTACK_CHANCE + 1;
			} else {
				this.attackChance = MAX_ATTACK_CHANCE;
			}
		}
	}
	
	// ## ==== other helpers ====
	public Card getInnerCard() {
		return this.innerCard;
	}

	interface UnitAbilityTrigger {
		void triggerAbility();
	}
	
	// Assignee: the provoke is implemented by @Yingbo Ge, together with the helper methods.
	/**call this function when construct a unit. A unit must know its inner card*/
	public void setInnerCard(Card card) {
		this.innerCard = card;
		this.health = card.getBigCard().getHealth();
		this.attack = card.getBigCard().getAttack();
		
		UnitAbilityTrigger builtInAbilityTrigger = () -> {
			if (this.getCardConfPath().equals(StaticConfFiles.c_azurite_lion)
					|| this.getCardConfPath().equals(StaticConfFiles.c_serpenti)) {
				
				// ## attack twice
				this.attackChance += 1;
//				System.out.println("Now I have " + this.attackChance + " times of attack");
			} else if (this.getCardConfPath().equals(StaticConfFiles.c_ironcliff_guardian)
					|| this.getCardConfPath().equals(StaticConfFiles.c_rock_pulveriser)
					|| this.getCardConfPath().equals(StaticConfFiles.c_silverguard_knight)){
				
				// ## provoke priority
				this.priorityLevel = AttackPriority.PROVOKE;
			}
		};
		builtInAbilityTrigger.triggerAbility();
	}
	
	public String getCardConfPath() {
		return this.getInnerCard() != null ? ((UnitCard) this.getInnerCard()).getCardConfPath() : "";
	}
	
	public String getUnitName() {
		return this.getInnerCard() != null ? this.getInnerCard().getCardname() : "";
	}
	
	public AbilityType getAbilityType() {
		if (this instanceof AvatarUnit) return AbilityType.BUILT_IN;
		else return ((HandCard) getInnerCard()).getAbilityType();
	}
	
	public Player getPlayer() {
		return this.player;
	}
	
	public void setPlayer(Player owner) {
		this.player = owner;
	}
	
	/**call inner damagedBy(ActorRef out, int damage) to deal with the damage*/
	public void damagedBy(ActorRef out, Unit attacker) {
		this.damagedBy(out, ((OperatableUnit) attacker).getAttack());
		System.out.printf("after being attacked, I, %s, now has health of %d\n", this.getClass(), this.getHealth());
	}
	
	/**re-set health = health - damage, will set health = 0 if it underflows. And display this message*/
	public void damagedBy(ActorRef out, int damage) {
		BasicCommands.playUnitAnimation(out, this, UnitAnimationType.hit);
		try {Thread.sleep(1200);} catch (Exception e) {e.printStackTrace();}
		
		this.setHealth(this.getHealth() - damage > 0 ? this.getHealth() - damage : 0);
		BasicCommands.setUnitHealth(out, this, this.health);
	}
	
	// ## ===================== unit range display interface ===============================
	interface unitRangeGenerator {
		LinkedList<int[]> generateRange();
	}
	
	// Assignee: the airdrop is implemented by @Yingbo Ge, together with the helper methods.
	/**compute range based on the raw range provided by GES's api */
	public LinkedList<int[]> unitGetMoveRange(int row, int col, GameState gameState) {
		unitRangeGenerator rangeGenerator = () -> {
			LinkedList<int[]> range = new LinkedList<>();
			
			// ## provoke test
			LinkedList<int[]> ifProvoked = gameState.whoseTurn().getAdjacentRangeAround(row, col, gameState, true);
			var iter = ifProvoked.iterator();
			while (iter.hasNext()) {
				int[] pos = iter.next();
				Unit unit = gameState.getCell(pos[0], pos[1]).getSurfaceUnit();
				if (((OperatableUnit) unit).getAttackPriority().equals(AttackPriority.PROVOKE)) {
					return range; // ## empty move range if provoked
				}
			}
			
			// ## if not provoked
			if (this.getCardConfPath().equals(StaticConfFiles.c_windshrike)) {
				
				// ## flying 
				range = gameState.whoseTurn().scanUnitInBoard(gameState, false, true); // all free tiles are ok to fly
			} else {
				
				// ## normal moving
				range = gameState.whoseTurn().getMoveRangeAround(row, col, gameState); // ## performance refined
			}
			return range;
		};
		return rangeGenerator.generateRange();
	}
	
	// Assignee: the flying is implemented by @Yingbo Ge, together with the helper methods.
	/**Call this method when human player needs to activate the move range*/
	public LinkedList<int[]> unitShowMoveRange(int row, int col, ActorRef out, GameState gameState) {
		
		var logicalRange = this.unitGetMoveRange(row, col, gameState);
		
		if (gameState.whoseTurn().getPlayer() instanceof HumanPlayer) {
			logicalRange.forEach(pos -> gameState.getCell(pos[0], pos[1]).displayWithMode(out, 1));
			gameState.whoseTurn().addRangeActivated(logicalRange);
		}
		
		return logicalRange;
	}
	
	/**comprehensive attack ranging method, call this method when need to display the attack range*/
	public LinkedList<int[]> unitShowAttackRange(int row, int col, ActorRef out, GameState gameState) {
		// ## adjacent attack range generator
		unitRangeGenerator attackRangeGenerator = () -> {
			LinkedList<int[]> range = new LinkedList<>();
			
			if (this.getCardConfPath().equals(StaticConfFiles.c_fire_spitter)
					|| this.getCardConfPath().equals(StaticConfFiles.c_pyromancer)) {
				// ## ranged attack
				range = gameState.whoseTurn().getRemoteRangeAround(gameState, true);
			} else {
				// ## normal adjacent attack
				range = gameState.whoseTurn().getAdjacentRangeAround(row, col, gameState, true);
			}
			
			// ## provoke filter - check whether this unit is in the provoking range, if so, replace range with provoked
			LinkedList<int[]> provokedReplacement = new LinkedList<>();
			var potentialAdjacentProvokers = gameState.whoseTurn().getAdjacentRangeAround(this.getRow(), this.getCol(), gameState, true);
			for ( var pos : potentialAdjacentProvokers) {
				OperatableUnit nextPotentialAdjProvoker = (OperatableUnit) gameState.getCell(pos[0], pos[1]).getSurfaceUnit();
				if (nextPotentialAdjProvoker.getAttackPriority().equals(AttackPriority.PROVOKE))
					provokedReplacement.add(new int[] {pos[0], pos[1]});
			}
			if (!provokedReplacement.isEmpty()) range = provokedReplacement;
			
			// ## display tiles
			range.forEach(pos -> gameState.getCell(pos[0], pos[1]).displayWithMode(out, 2));
			gameState.whoseTurn().addRangeActivated(range);
			
			return range;
		};
		
		var attackRange = attackRangeGenerator.generateRange();

		// ## extended range generator for move-then-attack strategy
		unitRangeGenerator extendedAttackRangeGenerator = () -> {
			if (!this.hasMoveChance() 
					|| this.getCardConfPath().equals(StaticConfFiles.c_fire_spitter)
					|| this.getCardConfPath().equals(StaticConfFiles.c_pyromancer)
					) {
				return new LinkedList<int[]>();
			}
			
			LinkedList<int[]> extendRange = new LinkedList<>();

			
			// ## scan all enemies on board
			var enemyPos = gameState.whoseTurn().scanUnitInBoard(gameState, true, false);
			var enemyPosIter = enemyPos.iterator();
			while (enemyPosIter.hasNext()) {
				int[] nextEnemyPos = enemyPosIter.next(); 
				// ## exclude the situation that the victim is already in attacker's adjacent range
				boolean existInAdj = false;
				for (var pos : attackRange) {
					if (Arrays.equals(pos, nextEnemyPos)) {
						existInAdj = true;
						break;
					}
				}
				if (existInAdj) continue;
				
				// ## check whether enemy is reachable
				LinkedList<int[]> moveRange = this.unitShowMoveRange(this.getRow(), this.getCol(), out, gameState);
				var enemyAdjRange = gameState.whoseTurn().getAdjacentRangeAround(nextEnemyPos[0], nextEnemyPos[1], gameState, false);
				var intersecRange = gameState.whoseTurn().intersection(moveRange, enemyAdjRange);
				if (intersecRange.size() > 0) { // ## if the intersection of move & adjacent is not empty, then add this enemy to attack range
					extendRange.add(nextEnemyPos);
				}
					
			}
			
			extendRange.forEach(pos -> gameState.getCell(pos[0], pos[1]).displayWithMode(out, 2));
			try {Thread.sleep(240);} catch (Exception e) {e.printStackTrace();}
			gameState.whoseTurn().addRangeActivated(extendRange);
			
			return extendRange;
		};
		
		var extendedRange = extendedAttackRangeGenerator.generateRange();
		
		attackRange.addAll(extendedRange); // ## move-attack extended range
		
//		// ## move then attack strategy checker
//		if (extendedRange.size() > 0) {
//			int[] extendedPos = extendedRange.pop();
//			gameState.getCell(extendedPos[0], extendedPos[1]).attackStrategyAdvisor(out, gameState.getCell(this.getRow(), this.getCol()), gameState);
//		}
		
		return attackRange;
	}
	
//	interface UnitAbilityTrigger {
//		void triggerAbility();
//	}
//	-> reminder
	// Assignee: the on-summon ability is implemented by @Yingbo Ge, together with the helper methods.
	// ========================= unit ability series ============================
	public void unitOnSummonAbilityTriggered(ActorRef out, GameState gameState) {
		UnitAbilityTrigger onSummonOrDeathAbilityTrigger = () -> {
			if (this.getCardConfPath().equals(StaticConfFiles.c_azure_herald)) {
				
				// Assignee: the avatar healing ability is implemented by @Yaqi Wang and @Xinyu Tian, together with the helper methods.
				// ## on summon - my avatar + 3H
				Player p1 = ((OperatableUnit) gameState.whoseTurn().getAvatarUnit()).getPlayer();
				Player p2 = this.getPlayer();
				if (p1.equals(p2)) {
					AvatarUnit myAvatar = ((AvatarUnit) gameState.whoseTurn().getAvatarUnit());
					myAvatar.gainHealth(out, gameState, 3);
				}
			} else if (this.getCardConfPath().equals(StaticConfFiles.c_blaze_hound)) {
				
				// ## on summon - both draw a card
				gameState.whoseTurn().supplementSingleCard(out);
				gameState.notWhoseTurn().supplementSingleCard(out);
			}
		};
		onSummonOrDeathAbilityTrigger.triggerAbility();
	}
	
	// Assignee: the on-death ability is implemented by @Yingbo Ge, together with the helper methods.
	public void unitOnDeathAbilityTriggered(ActorRef out, GameState gameState) {
		UnitAbilityTrigger onDeathAbilityTrigger = () -> {
			if (this.getCardConfPath().equals(StaticConfFiles.c_windshrike)) {
				
				// ## on death - owner draw a card
				Player unitOwner = this.getPlayer(); // ## unit owner
				if (gameState.whoseTurn().getPlayer().equals(unitOwner)) {
					gameState.whoseTurn().supplementSingleCard(out);	// ## current player is the owner, then -> current player draws a card
				} else {
					gameState.notWhoseTurn().supplementSingleCard(out);	// ## current player is not the owner, then -> counterpart draws a card
				}
			}
		};
		onDeathAbilityTrigger.triggerAbility();
	}
	
	// Assignee: the on-listened ability is implemented by @Yingbo Ge, together with the helper methods.
	/**unit ability of on-listened trigger*/
	public void unitOnListenedAbilityTriggered(ActorRef out, GameState gameState, InnerEventType event) {
		UnitAbilityTrigger onListenedTrigger = () -> {
			
			// ## identify whether there exists pureblade enforcer on the board regardless of its owner
			LinkedList<int[]> allUnits = gameState.whoseTurn().scanUnitInBoard(gameState, false, false);
			allUnits.addAll(gameState.whoseTurn().scanUnitInBoard(gameState, true, false));
			
			// ## identify all on listened unit on the board
			ArrayList<Unit> pureblade_enforcers = new ArrayList<>();
			ArrayList<Unit> silverguard_knights = new ArrayList<>();
			
			for (var iter = allUnits.iterator(); iter.hasNext(); ){
				int[] pos = iter.next();
				Unit nextUnit = gameState.getCell(pos[0], pos[1]).getSurfaceUnit();
				
				// ## scanning on-listen type unit to conduct triggered ability
				if (((OperatableUnit) nextUnit).getCardConfPath().equals(StaticConfFiles.c_pureblade_enforcer) ) {
					pureblade_enforcers.add(nextUnit);
				} else if (((OperatableUnit) nextUnit).getCardConfPath().equals(StaticConfFiles.c_silverguard_knight)){
					silverguard_knights.add(nextUnit);
				}
			}
			
			// ## for all pureblade_enforcers, check
			for (var iter = pureblade_enforcers.iterator(); iter.hasNext(); ) {
				
				Unit pureblade_enforcer = iter.next();
				if ( !(event.equals(InnerEventType.SPELL_CAST))) return;
				
				if (event.equals(InnerEventType.SPELL_CAST) && pureblade_enforcer != null) {
					// ## pureblade enforcer buff
					System.out.println("my pureblade enforcer found...");
					
					// ## listen to spell, and the spell should from an enemy
					HandCard card = ((HandCard) gameState.whoseTurn().getCardOnHold());
					if ( card!= null && card.isSpellCard()) {
						
						Player caster = gameState.whoseTurn().getPlayer();
						if ( !(caster.equals( ((OperatableUnit) pureblade_enforcer).getPlayer())) ) {
							
							// don't have to buff myself if i'm pureblade itself and is targeted by decay
							if ( ((HandCard) card).getCardConfPath().equals(StaticConfFiles.c_entropic_decay)
									&& this.getCardConfPath().equals(StaticConfFiles.c_pureblade_enforcer)
									&& this.equals(pureblade_enforcer)) {
								
								System.out.println("targeted");
								continue;
							}
							((OperatableUnit) pureblade_enforcer).gainBuff(out, gameState, 1, 1);
						}
					}
				}
			}
			
			// ## for all silverguard_knight, check
			for (var iter = silverguard_knights.iterator(); iter.hasNext(); ) {
				Unit silverguard_knight = iter.next();
				
				if ( !(event.equals(InnerEventType.AVATAR_DAMAGE))) return;
				
				if (event.equals(InnerEventType.AVATAR_DAMAGE) && this instanceof AvatarUnit && silverguard_knight != null) {
					// ## silverguard buff
					if (((OperatableUnit) silverguard_knight).getPlayer().equals(this.getPlayer())) {
						System.out.println("my silverguard_knight found...");
						((OperatableUnit) silverguard_knight).gainAttack(out, gameState, 2);
					}
				}
			}
		};
		onListenedTrigger.triggerAbility();
	}
}

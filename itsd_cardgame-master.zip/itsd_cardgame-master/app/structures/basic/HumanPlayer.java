package structures.basic;

public class HumanPlayer extends Player{

	String humanName;
	public HumanPlayer() {
		super();
		humanName = null;
	}
	
	public HumanPlayer(String name) {
		this.humanName = name;
	}
	
	public String getName() {
		return this.humanName;
	}

}

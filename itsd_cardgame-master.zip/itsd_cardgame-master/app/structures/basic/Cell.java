package structures.basic;

import java.util.Arrays;
import java.util.LinkedList;
import java.util.concurrent.locks.ReentrantLock;

import akka.actor.ActorRef;
import commands.BasicCommands;
import structures.GameException;
import structures.GameState;
import structures.InnerEventListener;
import utils.BasicObjectBuilders;
import utils.StaticConfFiles;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

import com.fasterxml.jackson.databind.introspect.TypeResolutionContext.Basic;

public class Cell implements InnerEventListener {

	final Logger log = LoggerFactory.getLogger(this.getClass());
	
	private Tile bottom;
	private Unit surface;
	private CellStatus cellStatus;
	private static final int THREAD_WAIT = 120;
	
	/**interface for processing all on-listend trigger ability type*/
	public void innerEventProcessor(Unit unit, InnerEventType eventType, ActorRef out, GameState gameState) {
		if (eventType.equals(InnerEventType.ON_SUMMON)) {
			
			// ## on summon ability triggered
			((OperatableUnit) unit).unitOnSummonAbilityTriggered(out, gameState);
		} else if (eventType.equals(InnerEventType.UNIT_DEALTH)) {
			
			// ## on death ability triggered
			((OperatableUnit) unit).unitOnDeathAbilityTriggered(out, gameState);
		} else if (eventType.equals(InnerEventType.SPELL_CAST)) {
			
			// ## listen to spell
			((OperatableUnit) unit).unitOnListenedAbilityTriggered(out, gameState, InnerEventType.SPELL_CAST);
		} else if (eventType.equals(InnerEventType.AVATAR_DAMAGE)) {
			
			// ## listen to avatar damage
			((OperatableUnit) unit).unitOnListenedAbilityTriggered(out, gameState, InnerEventType.AVATAR_DAMAGE);
		}
	}
	
	/**cell status and cell code is one of the CORE concept of our design*/
	public enum CellStatus {
		/*
		 * ======== Cell Status Definition ========
		 * -> TileMode:		0(clear), 			1(white), 		2(red)
		 * -> UnitMode:		0(no unit on it),	1(unit on it)
		 * -> ClickMode:	0(button pushed in),1(button pull off)
		 * 
		 *	No 	TileMode	UnitMode	ClickMode
		 * 	1	0			0			0
		 * 	2	0			0			1(invalid)
		 * 	3	0			1			0
		 * 	4	0			1			1
		 * 	5	1			0			0
		 * 	6	1			0			1
		 * 	7	1			1			0
		 * 	8	1			1			1
		 * 	9	2			0			0(undefined)
		 * 	10	2			0			1(undefined)
		 * 	11	2			1			0
		 * 	12	2			1			1
		 */
		DEFAULT("000"),
//		INVALID("001"),
		UNIT_DEFAULT("010"),
		UNIT_CLICKED("011"),
		TILE_MOVE_SUMMON_AVAILABLE("100"),
		TILE_MOVE_SUMMON_TARGETED("101"),
		SPELL_BUFF_AVAILABLE("110"),
		SPELL_BUFF_TARGETED("111"),
//		INVALID("200"),
//		INVALID("201"),
		UNIT_ATTACKED_AVAILABLE("210"),
		UNIT_ATTACKED_TARGETED("211");

		private final String statusCode;
		
		private CellStatus(String code) {
			this.statusCode = code;
		}
		
		public String getStatusCode() {
			return this.statusCode;
		}
		
		public String parseCodeDigitAt(int digitIndex) {
			return this.statusCode.substring(digitIndex, digitIndex + 1);
		}
	}
	
	public Cell(int row, int col) {
		this.bottom = BasicObjectBuilders.loadTile(col, row);
		this.surface = null;
		this.cellStatus = CellStatus.DEFAULT;
	}
	
	public Tile getBottomTile() {
		return this.bottom;
	}
	
	public Unit getSurfaceUnit() {
		return this.surface;
	}
	
	public CellStatus getCellStatus() {
		return this.cellStatus;
	}
	
	public Player whoseCell() {
		return ((OperatableUnit) this.getSurfaceUnit()).getPlayer();
	}
	
	// ## tested
	private void setCellStatus(String cellStatusCode) {
		for (var eachStatus : CellStatus.values()) {
			if (eachStatus.getStatusCode().equals(cellStatusCode)) {
				this.cellStatus = eachStatus;
				System.out.printf("==> status code [%s] has been set\n", this.cellStatus);
				return;
			}
		}
		System.out.println("==> Invalid cell state code");
	}
	
	private void setCellStatusDigit(int modeIndex, int digit) {
		String tileMode = this.getCellStatus().parseCodeDigitAt(0);
		String unitMode = this.getCellStatus().parseCodeDigitAt(1);
		String clickMode = this.getCellStatus().parseCodeDigitAt(2);
		
		if (modeIndex == 0) {
			tileMode = String.format("%d", digit);
			this.setCellStatus(tileMode + unitMode + clickMode);
		} else if (modeIndex == 1) {
			unitMode = String.format("%d", digit);
			this.setCellStatus(tileMode + unitMode + clickMode);
		} else if (modeIndex == 2) {
			clickMode = String.format("%d", digit);
			this.setCellStatus(tileMode + unitMode + clickMode);
		}
	}
	
	/**Call this method when this cell(tile) needs to be deployed with a unit*/
	public void setupNewUnit(Unit unit, ActorRef out, GameState gameState) {
		if (surface == null) {
			Lock lock = new ReentrantLock();
			lock.lock();
			BasicCommands.drawTile(out, bottom, 0);
//			try {Thread.sleep(THREAD_WAIT);} catch (InterruptedException e) {e.printStackTrace();}
			
			surface = unit;
			surface.setPositionByTile(bottom);
			BasicCommands.drawUnit(out, surface, bottom);
			try {Thread.sleep(THREAD_WAIT);} catch (InterruptedException e) {e.printStackTrace();}
			BasicCommands.setUnitAttack(out, surface, ((OperatableUnit) surface).getAttack());
			BasicCommands.setUnitHealth(out, surface, ((OperatableUnit) surface).getHealth());
			
			this.cellStatus = CellStatus.UNIT_DEFAULT;
			System.out.println("[Deployment - unit] with status [" + this.cellStatus + "]");
			lock.unlock();
			
			// ## nnnnnew test @22 Jun
			this.innerEventProcessor(unit, InnerEventType.ON_SUMMON, out, gameState);
		} else {
			; // Spell card can stack on existing units.
			System.out.println("Error: there exists unit on this tile");
			this.cleanUpDeadGhost(out, gameState);
		}
	}
	
	/**similar method dedicated to setup unit who just stopped(do not refresh)*/
	public void setupStoppedUnit(Unit unit, ActorRef out, GameState gameState) {
		if (surface == null) {
			Lock lock = new ReentrantLock();
			lock.lock();
			
			surface = unit;
			surface.setPositionByTile(bottom);
			this.cellStatus = CellStatus.UNIT_DEFAULT;
			System.out.println("[Replacement - unit] with status [" + this.cellStatus + "]");
			
			lock.unlock();
		}
	}
	
	// Assignee: the unit death is implemented by @Yueyue Liu and @You Li, together with the helper methods.
	// Assignee: the game win/loss is implemented by @Yingbo Ge and @Xinyu Tian, together with the helper methods.
	/**Call this method when the unit on this cell(tile) is removed*/
	public void destroyUnitOnIt(ActorRef out, GameState gameState) {
		
		try {
			if (this.surface == null) throw new GameException("Error: no units on this cell to delete!");
			
			// ## on death ability trigger before deletion
			this.innerEventProcessor(surface, InnerEventType.UNIT_DEALTH, out, gameState);
			
			// ## check game loss/win
			BasicCommands.playUnitAnimation(out, this.surface, UnitAnimationType.death);
			try { Thread.sleep(1200);} catch (Exception e) { e.printStackTrace(); }
			if (this.surface instanceof AvatarUnit) {
				if (((OperatableUnit) this.surface).getPlayer() instanceof AiPlayer) {
//					BasicCommands.addPlayer2Notification(out, "GGWP, I(ai) lose the game", 6);
					BasicCommands.addPlayer1Notification(out, "Victory!", 6);
				} else {
					BasicCommands.addPlayer1Notification(out, "GGWP, I(human)lose the game", 6);
//					BasicCommands.addPlayer2Notification(out, "Victory", 6);
				}
				gameState.endTheGame();
			}
			
			this.cleanUpDeadGhost(out, gameState);
		} catch (GameException e) {
			log.error("Cannot delete an empty cell", e);
			e.printStackTrace();
		}
	}
	
	public void cleanUpDeadGhost(ActorRef out, GameState gameState) {
		BasicCommands.deleteUnit(out, surface);
		this.cleanUpStoppedGhost(out, gameState);
	}
	
	public void cleanUpStoppedGhost(ActorRef out, GameState gameState) {
		this.surface = null;
		this.cellStatus = CellStatus.DEFAULT;
		displayWithMode(out, 0);
	}

	/**this method gives options whether to opt for single attack or move-then-attack*/
	public void getAttackedStrategyAdvisor(ActorRef out, Cell attacker, GameState gameState) {
		
		log.info("Validating attack options...");	// ## opt1 - ranged; opt2 - adj attack; opt3 - move-then-adj attack
		
		// Assignee: the ranged attack is implemented by @Yueyue Liu and @Yaqi Wang, together with the helper methods.
		// ## special ranged attack
		if (((OperatableUnit) attacker.getSurfaceUnit()).getCardConfPath().equals(StaticConfFiles.c_fire_spitter)
				|| ((OperatableUnit) attacker.getSurfaceUnit()).getCardConfPath().equals(StaticConfFiles.c_pyromancer)) {
			
			log.info(String.format("this unit on tile[%d][%d] just need get a RANGED single attack", this.surface.getRow(), this.surface.getCol()));
			
			gameState.whoseTurn().clearRangeActivated(out, gameState);
			try {Thread.sleep(240);} catch (Exception e) {e.printStackTrace();}
			
			getSingleAttackedBy(out, attacker, gameState);
			
			return;
		}
		
		// ## if the victim is in the attacker's adjacent range then -> a single attack will be fine
		var attackerAdjRange = gameState.whoseTurn().getAdjacentRangeAround(attacker.getSurfaceUnit().getRow(), attacker.getSurfaceUnit().getCol(), gameState, true);
		var thisPos = new LinkedList<int[]>();
		thisPos.add(new int[] {surface.getRow(), surface.getCol()});
		var inAdjacentRange = gameState.whoseTurn().intersection(attackerAdjRange, thisPos);
		
		if (inAdjacentRange.size() > 0) {
			log.info(String.format("this unit on tile[%d][%d] just need get an ADJACENT single attack", this.surface.getRow(), this.surface.getCol()));
			
			gameState.whoseTurn().clearRangeActivated(out, gameState);
			try {Thread.sleep(240);} catch (Exception e) {e.printStackTrace();}
			
			getSingleAttackedBy(out, attacker, gameState);
			
			return;
		} 
			
		// ## if the victim's adjacent range is in the intersection of attacker's move range, then -> move and attack;
		OperatableUnit attackerUnit = ((OperatableUnit) attacker.getSurfaceUnit());
		var attackerMoveRange = attackerUnit.unitGetMoveRange(attackerUnit.getRow(), attackerUnit.getCol(), gameState);
		var victimAdjRange = gameState.whoseTurn().getAdjacentRangeAround(surface.getRow(), surface.getCol(), gameState, false);
		var junctions = gameState.whoseTurn().intersection(attackerMoveRange, victimAdjRange);
		
		if (junctions.size() == 0) {
			
			log.info("Out of reach");
			
			return;
		} else {
			
			int[] tmp = junctions.pop();
			log.info(String.format("move & attack strategy should be applied, go to next tile[%d][%d]\n", tmp[0], tmp[1]));
			
			gameState.whoseTurn().clearRangeActivated(out, gameState);
			try {Thread.sleep(240);} catch (Exception e) {e.printStackTrace();}
			
			moveThenAttack(out, attacker, gameState, tmp);
			
			return;
		}
	}
	
	// Assignee: the move-then-attack is implemented by @Yingbo Ge, together with the helper methods.
	/**move-then-attack strategy helper method*/
	private void moveThenAttack(ActorRef out, Cell attacker, GameState gameState, int[] junction) {
		Lock lock = new ReentrantLock();
		lock.lock();
		
		// ## reach to this tile
		Cell destination = gameState.getCell(junction[0], junction[1]);	
		gameState.whoseTurn().moveUnitToCell(out, gameState, destination);
		
		// ## update attacker's info due to movement
		attacker = gameState.getCell(junction[0], junction[1]);
		gameState.whoseTurn().setUnitLastClicked(attacker.surface);
		
		// ## conduct attack
		try {Thread.sleep(1000);} catch (Exception e) {e.printStackTrace();}
		getSingleAttackedBy(out, attacker, gameState);
		
		lock.unlock();
	}
	
	// ## ======================Attacking logic=================================
	/*
	 * 	Attack Receiver(receives attack) 	<-		Attack Launcher
	 * 
	 * 							Stage 1 - receives damage
	 * 		-> Stage 1.a - destroy immediately		
	 * 					ATTACK OVER					ATTACK OVER
	 * 		-> Stage 1.b - healthy, in the range, counter-attack
	 * 
	 * 							Stage 2 - counter-attack
	 * 												-> Stage 2.a - destroy immediately
	 * 												-> Stage 2.b - healthy, standing still
	 * 					ATTACK OVER					ATTACK OVER
	 */
	public void getSingleAttackedBy(ActorRef out, Cell attacker, GameState gameState) {
		Lock lock = new ReentrantLock();
		lock.lock();
		
		Unit attackerUnit = attacker.getSurfaceUnit();
		
		// ## ===================Stage 1 receives damage=================================
		if ( this.surface != null 								// ## this cell has unit
				&& ((OperatableUnit) this.surface).isHealthy() ) { // ## healthy enough to be attacked
			
			System.out.println("==> conducting attacking operation...");
			
			// ## animation take 1200ms so play the animation first
			BasicCommands.playUnitAnimation(out, attackerUnit, UnitAnimationType.attack);
			try { Thread.sleep(1200);} catch (Exception e) { e.printStackTrace(); }
			
			// !## special animation for ranged attack
			if (((OperatableUnit) attackerUnit).getCardConfPath().equals(StaticConfFiles.c_fire_spitter)
					|| ((OperatableUnit) attackerUnit).getCardConfPath().equals(StaticConfFiles.c_pyromancer)) {
				EffectAnimation effect = BasicObjectBuilders.loadEffect(StaticConfFiles.f1_projectiles);
				BasicCommands.playProjectileAnimation(out, effect, 0, attacker.getBottomTile(), this.bottom); // ## 0 - red dot; 1 - white dot; 2 - white shoot
				try { Thread.sleep(1200);} catch (Exception e) { e.printStackTrace(); }
			}

			// ## logical attacks: attacker cause damage and its chance to attack - 1
			((OperatableUnit) this.surface).damagedBy(out, attackerUnit);
			
			if (this.surface instanceof AvatarUnit)
				innerEventProcessor(this.surface, InnerEventType.AVATAR_DAMAGE, out, gameState);
			
			((OperatableUnit) attackerUnit).attackPerformed();
			BasicCommands.playUnitAnimation(out, attackerUnit, UnitAnimationType.idle);
		}
		
		if ( !((OperatableUnit) this.surface).isHealthy()) {
			
			// ## ----------------Stage 1.a - unable to counter-attack, destroy immediately----------------
			this.destroyUnitOnIt(out, gameState);
			return;
		} else {
			
			// Assignee: the counter-attack is implemented by @Yingbo Ge, @Yueyue Liu and @Xinyu Tian, together with the helper methods.
			// ## ----------------Stage 1.b - health, attacker in the counter-attack range?----------------
			BasicCommands.playUnitAnimation(out, this.surface, UnitAnimationType.idle);
			
			// ## surface unit may have been deleted due to stage 1.a
			if ( this.surface != null
					&& this.surface instanceof OperatableUnit
					&& ((OperatableUnit) this.surface).isHealthy() ){
				
				// ## check whether attacker is in the range.
				var myCounterAttackRange = new LinkedList<int[]>();
				boolean rangedCounterAttack = false;
				if (((OperatableUnit) this.surface).getCardConfPath().equals(StaticConfFiles.c_fire_spitter)
						|| ((OperatableUnit) this.surface).getCardConfPath().equals(StaticConfFiles.c_pyromancer)) {
					// ## !whoseTurn() ~ equals to counterpart's turn
					myCounterAttackRange = gameState.notWhoseTurn().getRemoteRangeAround(gameState, true);
					rangedCounterAttack = true;
				} else {
					myCounterAttackRange = gameState.notWhoseTurn().getAdjacentRangeAround(surface.getRow(), surface.getCol(), gameState, true);
				}
//				myCounterAttackRange.forEach(pos -> System.out.println(pos[0] +  " " + pos[1]));
				int[] attackerPos = new int[] {attacker.getSurfaceUnit().getRow(), attacker.getSurfaceUnit().getCol()};
				boolean attackerIsReachable = false;
				for (var pos : myCounterAttackRange) {
					attackerIsReachable = Arrays.equals(attackerPos, pos);
					if (attackerIsReachable) break;
				}
				
				if (!attackerIsReachable) {
					System.out.printf("counter-attack targets[%d][%d] out of range\n", attackerPos[0], attackerPos[1]);
					return;
				} else {
					System.out.printf("counter-attack targets[%d][%d] in the range\n", attackerPos[0], attackerPos[1]);
				}
				
				// ## ===================Stage 2 receiver counter-attacks===============================
				// ## counter-attack animation
				System.out.println("==> conducting counter-attack operation...");
				BasicCommands.playUnitAnimation(out, this.surface, UnitAnimationType.attack);
				try { Thread.sleep(1200);} catch (Exception e) { e.printStackTrace(); }
				
				// !## special animation for ranged counter-attack
				if (rangedCounterAttack) {
					EffectAnimation effect = BasicObjectBuilders.loadEffect(StaticConfFiles.f1_projectiles);
					BasicCommands.playProjectileAnimation(out, effect, 0, this.bottom, attacker.getBottomTile());
					try { Thread.sleep(1200);} catch (Exception e) { e.printStackTrace(); }
				}
				
				// ## counter-attack doesn't consume chance to attack
				((OperatableUnit) attackerUnit).damagedBy(out, this.surface);
				if (attackerUnit instanceof AvatarUnit)
					innerEventProcessor(attackerUnit, InnerEventType.AVATAR_DAMAGE, out, gameState);
				BasicCommands.playUnitAnimation(out, this.surface, UnitAnimationType.idle);
			}
			
			if ( !((OperatableUnit) attackerUnit).isHealthy()) {
				// ## -------------------Stage 2.a - destroy immediately------------------------------
				attacker.destroyUnitOnIt(out, gameState);
				return;
			} else {
				// ## -------------------Stage 2.b - healthy, standing still and do nothing-----------
				BasicCommands.playUnitAnimation(out, attackerUnit, UnitAnimationType.idle);
			}
		}
		lock.unlock();
		// end of attack
	}
	
	/**redraw tile with tile display mode 0, 1 or 2*/
	public void displayWithMode(ActorRef out, int tileModeCode) {	// ## tileModeCode = 0 clear, 1 white, 2 red

		String tileModeToDraw = String.format("%d", tileModeCode);		// ## tileMode
//		String tileMode = this.getCellStatus().parseCodeDigitAt(0);		// ## tileMode(original)
		String unitMode = this.getCellStatus().parseCodeDigitAt(1);		// ## unitMode(original)
		String clickMode = this.getCellStatus().parseCodeDigitAt(2);	// ## clickMode(original)
		
		BasicCommands.drawTile(out, bottom, tileModeCode);
		this.setCellStatus(tileModeToDraw + unitMode + clickMode);
	}
	
	// ## ============= Status Code helper methods ================ ##
	
	// ## cell status code helper series No.1: unit clicked/undo click
	// ## tested ~equals to "010"
	public boolean tileHasUnit() {
		String unitMode = this.getCellStatus().parseCodeDigitAt(1);
		return unitMode.equals("1") ? true : false;
	}
	
	// ## tested ~equals to "011"
	public boolean unitIsTriggered() {
		String clickMode = this.getCellStatus().parseCodeDigitAt(2);
		return (tileHasUnit() && clickMode.equals("1") ) ? true : false;  
	}
	
	// ## tested ~equals to "010"->"011"
	public void unitTriggerPerformed() {
		if (!unitIsTriggered()) this.setCellStatusDigit(2, 1);
	}
	
	// ## tested ~equals to "011"->"010"
	public void unitTriggerUndo() {
		if (unitIsTriggered()) this.setCellStatusDigit(2, 0);
	}
	
	// ## cell status code helper series No.2: move & attack
	// ## ~equals to "100"
	public boolean tileIsAvailableForMoveOrSummon() {
		return this.getCellStatus().equals(CellStatus.TILE_MOVE_SUMMON_AVAILABLE) ? true : false;
	}
	
	// ## cell status code helper series No.3: attack / attack performed
	// ## ~equals to "210"
	public boolean unitIsAvailableForAttack() {
		return this.getCellStatus().equals(CellStatus.UNIT_ATTACKED_AVAILABLE) ? true : false;
	} 
	
	public boolean unitIsAvailableForBuff() {
		return this.getCellStatus().equals(CellStatus.SPELL_BUFF_AVAILABLE) ? true : false;
	}
}

package structures.basic;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Map;
import java.util.Objects;

import com.fasterxml.jackson.databind.introspect.TypeResolutionContext.Basic;

import akka.actor.ActorRef;
import akka.util.Collections;
import commands.BasicCommands;
import structures.GameElementSet;
import structures.GameException;
import structures.basic.HandCard.AbilityType;
import utils.BasicObjectBuilders;
import utils.StaticConfFiles;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Hand {
	
	final Logger log = LoggerFactory.getLogger(this.getClass());
	
	private GameElementSet owner;
	private ArrayList<String> cardConfPathArray6;
	private Map<String, Card> cardConfPathCohesionID2Card;	// ## String -> Card (HandCard.java)
									// ## cohesion ID = cardConfPath + Stringfy(hand position)
	private Map<String,	String> cardConfPath2UnitConfPath;	// ## String -> String (unitConfPath)
	private Map<String, AbilityType> cardConfPath2Type;		// ## String -> AbilityType (Enum)
	private int lastAddedHandPosition;						// ## position ~[1, 6] both inclusive
	
	private static int cardIndex = 0;

	private final int HAND_CAPACITY = 6;
	
	public Hand() {
		this.owner = null;
		this.cardConfPathArray6 = new ArrayList<>(HAND_CAPACITY);
		for (int i = 0; i < HAND_CAPACITY; i++) 
			this.cardConfPathArray6.add(null);
		
//		this.cardConfPath2Card = new HashMap<>(); // replace this one
		this.cardConfPathCohesionID2Card = new HashMap<>();
		this.cardConfPath2UnitConfPath = new HashMap<>();
		this.cardConfPath2Type = new HashMap<>();
		
		lastAddedHandPosition = -1;

		// ## 15 cards mapped with units; 15 = 20(total) - 4(spell) - 1(shared)
		cardConfPath2UnitConfPath.put(StaticConfFiles.c_azure_herald, StaticConfFiles.u_azure_herald);
		cardConfPath2UnitConfPath.put(StaticConfFiles.c_azurite_lion, StaticConfFiles.u_azurite_lion);
		cardConfPath2UnitConfPath.put(StaticConfFiles.c_comodo_charger, StaticConfFiles.u_comodo_charger);
		cardConfPath2UnitConfPath.put(StaticConfFiles.c_fire_spitter, StaticConfFiles.u_fire_spitter);
		cardConfPath2UnitConfPath.put(StaticConfFiles.c_hailstone_golem, StaticConfFiles.u_hailstone_golem);
		cardConfPath2UnitConfPath.put(StaticConfFiles.c_ironcliff_guardian, StaticConfFiles.u_ironcliff_guardian);
		cardConfPath2UnitConfPath.put(StaticConfFiles.c_pureblade_enforcer, StaticConfFiles.u_pureblade_enforcer);
		cardConfPath2UnitConfPath.put(StaticConfFiles.c_silverguard_knight, StaticConfFiles.u_silverguard_knight);
		cardConfPath2UnitConfPath.put(StaticConfFiles.c_blaze_hound, StaticConfFiles.u_blaze_hound);
		cardConfPath2UnitConfPath.put(StaticConfFiles.c_bloodshard_golem, StaticConfFiles.u_bloodshard_golem);
		cardConfPath2UnitConfPath.put(StaticConfFiles.c_planar_scout, StaticConfFiles.u_planar_scout);
		cardConfPath2UnitConfPath.put(StaticConfFiles.c_pyromancer, StaticConfFiles.u_pyromancer);
		cardConfPath2UnitConfPath.put(StaticConfFiles.c_serpenti, StaticConfFiles.u_serpenti);
		cardConfPath2UnitConfPath.put(StaticConfFiles.c_rock_pulveriser, StaticConfFiles.u_rock_pulveriser);
		cardConfPath2UnitConfPath.put(StaticConfFiles.c_windshrike, StaticConfFiles.u_windshrike);
		
		// ## 19 cards mapped with Enum ability types; 19 = 4(spell_card) + 7(deck1 unit_card) + 7(deck2 unit_card) + 1(shared unit_card)
		cardConfPath2Type.put(StaticConfFiles.c_truestrike, AbilityType.ON_TIME_SPELL);		// spell
		cardConfPath2Type.put(StaticConfFiles.c_sundrop_elixir, AbilityType.ON_TIME_SPELL); // spell
		cardConfPath2Type.put(StaticConfFiles.c_staff_of_ykir, AbilityType.ON_TIME_SPELL);	// spell
		cardConfPath2Type.put(StaticConfFiles.c_entropic_decay, AbilityType.ON_TIME_SPELL); // spell
		
		cardConfPath2Type.put(StaticConfFiles.c_pureblade_enforcer, AbilityType.TRIGGERED);	// cast spell - gain A/H
		cardConfPath2Type.put(StaticConfFiles.c_azure_herald, AbilityType.TRIGGERED);		// summon - gain H
		cardConfPath2Type.put(StaticConfFiles.c_blaze_hound, AbilityType.TRIGGERED);		// draw card
		
		cardConfPath2Type.put(StaticConfFiles.c_silverguard_knight, AbilityType.BUILT_IN_AND_TRIGGERED); 	// mixed, provoke + gain 2A when avatar is damaged
		cardConfPath2Type.put(StaticConfFiles.c_windshrike, AbilityType.BUILT_IN_AND_TRIGGERED);			// mixed, flying + draw card when this unit died
		cardConfPath2Type.put(StaticConfFiles.c_ironcliff_guardian, AbilityType.BUILT_IN_AND_TRIGGERED);	// mixed, provoke + airdrop
		
		cardConfPath2Type.put(StaticConfFiles.c_fire_spitter, AbilityType.BUILT_IN);	// ranged
		cardConfPath2Type.put(StaticConfFiles.c_pyromancer, AbilityType.BUILT_IN);		// ranged
		cardConfPath2Type.put(StaticConfFiles.c_azurite_lion, AbilityType.BUILT_IN);	// attack twice/turn
		cardConfPath2Type.put(StaticConfFiles.c_serpenti, AbilityType.BUILT_IN);		// attack twice/turn
		cardConfPath2Type.put(StaticConfFiles.c_rock_pulveriser, AbilityType.BUILT_IN); // provoke
		cardConfPath2Type.put(StaticConfFiles.c_planar_scout, AbilityType.BUILT_IN); 	// airdrop
		
		cardConfPath2Type.put(StaticConfFiles.c_comodo_charger, AbilityType.BUILT_IN);	 // nothing
		cardConfPath2Type.put(StaticConfFiles.c_hailstone_golem, AbilityType.BUILT_IN);  // nothing
		cardConfPath2Type.put(StaticConfFiles.c_bloodshard_golem, AbilityType.BUILT_IN); // nothing
	}
	
	public void setOwner(GameElementSet owner) {
		this.owner = owner;
	}
	
//	public int getOwnerGesId() {
//		return this.owner.getGesID();
//	}
	
	public int getHandSize() {
		int size = 0;
		var iter = cardConfPathArray6.iterator();
		while (iter.hasNext()) {
			if (iter.next() != null) size++;
		}
		return size;
	}
	
	/**AI randomly pick a card*/
	public LinkedList<Card> getRandomCards(int mana) {
		LinkedList<Card> randomCards = new LinkedList<>();
		int posIndex = 0;
		
		var handposIter = cardConfPathArray6.iterator();
		while (handposIter.hasNext() && posIndex <= 5) { // traversal every hand position
			if (handposIter.next() == null) continue;
			
			try {
				var nextCard = getCardEntity(++posIndex);
				if (nextCard != null && nextCard.getManacost() <= mana)
					randomCards.add(nextCard);
			} catch (GameException e) {e.printStackTrace();}
		}
		return randomCards;
	}
	
	/**Return the hand position of last time added to the hand*/
	public int getLastAddedHandPosition() {
		return this.lastAddedHandPosition;
	}
	
	/**Return card ability type of the given cardConfPath*/
	public AbilityType getAbilityType(String cardConfPath) {
		return this.cardConfPath2Type.get(cardConfPath);
	}
	
	// ## =========================== Hashmap helper 1: get unit configuration file path===================================
	/**Convert a cardConfPath String to a proper unitConfPath String. Throws an GameException when the given path is wrong*/
	public String convert2UnitConfPath(String cardConfPath) throws GameException {
		String unitConfPath = this.cardConfPath2UnitConfPath.get(cardConfPath);
		if (unitConfPath == null) {
			throw new GameException("[Error, conf file path mismatched] - Cannot convert to unitConfPath for this cardConfPath[" + cardConfPath + "]");
		}

		// ## deal with the shared card
		if (this.owner.getPlayer() instanceof AiPlayer 
				&& cardConfPath.equals(StaticConfFiles.c_hailstone_golem) ) {
			
			System.out.println(unitConfPath);
			String[] tmp = unitConfPath.split(".json");
			unitConfPath = String.format(tmp[0] + "2.json");
			System.out.println(unitConfPath);
		}
		return unitConfPath;
	}
	
	// Assignee: the overdraw is implemented by @Yueyue Liu and @Yaqi Wang, together with the helper methods.
	/**Add a cardConfPath string to hand list and mapping it with a Card object using builder*/
	public void addCard(String cardConfPath) {
		
		// ## step 1 - prepare the position to insert into hand; return -1 when hand is full
		int emptyIndex = cardConfPathArray6.indexOf(null);
		if (emptyIndex == -1) {
			System.out.println("[Dropped - Full Hand] card has been dropped");
			return;
		} 
		
		// ## step 2 - added to the linkedList
		cardConfPathArray6.set(emptyIndex, cardConfPath);
		
		// ## step 3 - build card, then -> mapping cardConfPath + handpos to Card
		// e.g., conf/gameconfs/cards/1_c_u_hailstone_golem.json + handposition[1, 2, ..., 6]
		String type = cardConfPath.split("_")[2];	// ## "u" or "s"?
		Card card = BasicObjectBuilders.loadCard(cardConfPath, ++cardIndex, type.equals("u") ? UnitCard.class : SpellCard.class);
		((HandCard) card).setCardConfPath(cardConfPath);
		((HandCard) card).setAbilityType(this.getAbilityType(cardConfPath));
		((HandCard) card).setPrevHandPosition(emptyIndex + 1);
		cardConfPathCohesionID2Card.put(String.format("%s%d", cardConfPath, emptyIndex + 1), card);	// repeated card problem, replace this with cohesion id
		
		System.out.printf("card added: %s%d\n", cardConfPath, emptyIndex + 1);
		
		// ## step 4 - record this hand position as last added
		this.lastAddedHandPosition = emptyIndex + 1;
	}
	
	/**Delete a Key-Value mapping and reset element on that hand position to NULL*/
	public void deleteCard(int handPosition) {
		try {
			// ## step 1 - legal position check
			if (handPosition > 0 && handPosition <= 6) { // ~[1,6]
				
				// ## step 2 - firstly remove the mapping , then -> set that element to null 
				String cardConfPathToDelete = cardConfPathArray6.get(handPosition - 1);
				log.warn(String.format("BEFORE clean up - hand now has %d cards", this.getHandSize()));
				log.warn(String.format("preparing clean up of card %s", cardConfPathToDelete));
				cardConfPathCohesionID2Card.remove(String.format("%s%d", cardConfPathToDelete, handPosition));
				cardConfPathArray6.set(handPosition - 1, null);
				log.warn(String.format("AFTER clean up - hand now has %d cards", this.getHandSize()));
			} else {
				throw new GameException(String.format("[Error] - that hand position[%d] does not have a card to delete", handPosition));
			}
			
		} catch (GameException e) {e.printStackTrace();}
	}
	
	/**Display or delete card at the given position ~[1, 6] in the front-end
	 * @param displayMode indicates whether card is displayed with highlight or not*/
	public void displayCard(ActorRef out, int handPosition, int displayMode, boolean deletion) {
		if (this.owner.getGesID() == 2) return;
		if (deletion) { 
			
			// ## delete that card
			BasicCommands.deleteCard(out, handPosition);
		} else {
			
			// ## display that card with highlight [ON] / [OFF]
			try {
				Card card = getCardEntity(handPosition);
				BasicCommands.drawCard(out, card, handPosition, displayMode);
			} catch (GameException e) { 
				log.error("get card entity failed, check the hand position", e);
				e.printStackTrace();
			}
		}
	}
	
	/**Return the string of the configuration file path of certain card in the given hand position
	 * @param handPosition ~ [1, 6], both start & end inclusive*/
	private String getCardConfPath(int handPosition) {	// ## index:[1, 6]
		
		// ## filter invalid  hand position
		while (handPosition <= 0) handPosition += 6;
		while (handPosition > 6) handPosition %= 6;
		return this.cardConfPathArray6.get(handPosition - 1);
	}
	
	/**Return the card in the given position
	 * @return a Card object if it exists in that position; otherwise returns NULL*/
	public Card getCardEntity(int handPosition) throws GameException {
		String cardConfPath = getCardConfPath(handPosition);
		
		if (cardConfPath == null) {
			log.warn(String.format("[WARNING] - hand position[%d] (=hand index[%d]) currently does NOT have a card", handPosition, handPosition - 1));
			return null;
		} else {
			Card card = cardConfPathCohesionID2Card.get(String.format("%s%d", cardConfPath, handPosition));
			if (card == null)
				throw new GameException(String.format("[Error] - cannot map the card for the given card  conf path[%s]", cardConfPath));
			return card;
		}
	}
	
}

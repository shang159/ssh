package structures.basic;

import java.util.LinkedList;

import akka.actor.ActorRef;
import commands.BasicCommands;
import structures.GameState;
import structures.InnerEventListener.InnerEventType;
import utils.BasicObjectBuilders;
import utils.StaticConfFiles;

public class SpellCard extends HandCard {
	
	interface SpellRangeGenerator {
		LinkedList<int[]> generateRange();
	}
	
	interface SpellAbilityLauncher {
		void launchAbility();
	}

	public SpellCard() {
		super();
	}
	
	private void cardDeployedCleanUp(ActorRef out, GameState gameState) {
		// ## clean up step 1 - reset unit clicked status
		gameState.whoseTurn().setUnitLastClicked(null);
		// ## clean up step 2 - delete the deployed card
		gameState.whoseTurn().deleteDeployedCardFromHand(out);
		// ## clean up step 3 - reset card on hold status
		gameState.whoseTurn().setCardOnHold(null);
	}
	
	// Assignee: the spell targeting is implemented by @Yingbo Ge and @Xinyu Tian, together with the helper methods.
	public LinkedList<int[]> spellShowTargetUnit(ActorRef out, GameState gameState) {
		SpellRangeGenerator rangeGenerator = () -> {
			LinkedList<int[]> range = new LinkedList<>();
			if (this.getCardConfPath().equals(StaticConfFiles.c_truestrike)) {
				
				// ## debuff
				range = gameState.whoseTurn().scanUnitInBoard(gameState, true, false);
				range.forEach(pos -> gameState.getCell(pos[0], pos[1]).displayWithMode(out, 2));
			} else if (this.getCardConfPath().equals(StaticConfFiles.c_entropic_decay)) {
				
				// ## debuff except avatar
				range = gameState.whoseTurn().scanUnitInBoard(gameState, true, false);
				var iter = range.iterator();
				while (iter.hasNext()) {
					int[] pos = iter.next();
					if ( ((OperatableUnit) gameState.getCell(pos[0], pos[1]).getSurfaceUnit()) instanceof AvatarUnit) {
						iter.remove();
						break;
					}
				}
				range.forEach(pos -> gameState.getCell(pos[0], pos[1]).displayWithMode(out, 2));
			} else if (this.getCardConfPath().equals(StaticConfFiles.c_sundrop_elixir)) {
				
				// ## buff
				range = gameState.whoseTurn().scanUnitInBoard(gameState, false, false);
				range.forEach(pos -> gameState.getCell(pos[0], pos[1]).displayWithMode(out, 1));
			} else if (this.getCardConfPath().equals(StaticConfFiles.c_staff_of_ykir)) {
				
				// ## buff only with avatar
				range = gameState.whoseTurn().scanUnitInBoard(gameState, false, false);
				var iter = range.iterator();
				while (iter.hasNext()) {
					int[] pos = iter.next();
					if ( ! (((OperatableUnit) gameState.getCell(pos[0], pos[1]).getSurfaceUnit()) instanceof AvatarUnit) ) {
						iter.remove();
					}
				}
				range.forEach(pos -> gameState.getCell(pos[0], pos[1]).displayWithMode(out, 1));
			}
			gameState.whoseTurn().addRangeActivated(range);
			return range;
		};
		
		return rangeGenerator.generateRange();
	}
	
	// Assignee: the playing spell cards is implemented by @Yueyue Liu and @Xinyu Tian, together with the helper methods.
	public void spellAbilityTriggered(ActorRef out, GameState gameState) {
		
		SpellAbilityLauncher abilityLauncher = () -> {
			
			if (this.getCardConfPath().equals(StaticConfFiles.c_truestrike)) {
				
				// Assignee: the direct-death is implemented by @Yaqi Wang and @Xinyu Tian, together with the helper methods.
				// ## spell truestrike
				Unit unitTobeAttacked = gameState.whoseTurn().getUnitLastClicked();
				((OperatableUnit) unitTobeAttacked).damagedBy(out, 2);
				
				// ## check whether unit is healthy
				if ( !((OperatableUnit) unitTobeAttacked).isHealthy())
					gameState.getCell(unitTobeAttacked.getRow(), unitTobeAttacked.getCol()).destroyUnitOnIt(out, gameState);
				else
					BasicCommands.playUnitAnimation(out, unitTobeAttacked, UnitAnimationType.idle);
			} else if (this.getCardConfPath().equals(StaticConfFiles.c_entropic_decay)) {
				
				// Assignee: the direct-death is implemented by @Yingbo Ge and @Xinyu Tian, together with the helper methods.
				// ## spell entropic decay
				Unit unitTobeAttacked = gameState.whoseTurn().getUnitLastClicked();
				((OperatableUnit) unitTobeAttacked).damagedBy(out, 21);
				
				// ## check whether unit is healthy
				if ( !((OperatableUnit) unitTobeAttacked).isHealthy()) 
					gameState.getCell(unitTobeAttacked.getRow(), unitTobeAttacked.getCol()).destroyUnitOnIt(out, gameState);
				else 
					BasicCommands.playUnitAnimation(out, unitTobeAttacked, UnitAnimationType.idle);
			} else if (this.getCardConfPath().equals(StaticConfFiles.c_sundrop_elixir)) {
				
				// Assignee: the healing spell is implemented by @Yueyue Liu, together with the helper methods.
				// ## spell sundrop elixir
				Unit unitTobeBuffed = gameState.whoseTurn().getUnitLastClicked();
				((OperatableUnit) unitTobeBuffed).gainHealth(out, gameState, 5); // ## tested
			} else if (this.getCardConfPath().equals(StaticConfFiles.c_staff_of_ykir)) {
			
				// Assignee: the unit buff is implemented by @Yingbo Ge and @Xinyu Tian, together with the helper methods.
				// ## spell staff of ykir
				Unit unitTobeBuffed = gameState.whoseTurn().getUnitLastClicked();
				((OperatableUnit) unitTobeBuffed).gainAttack(out, gameState, 2); // ## tested
			}
			return;
		};
		
		// ## clear the existing range display
		gameState.whoseTurn().clearRangeActivated(out, gameState);

		int row = gameState.whoseTurn().getUnitLastClicked().getRow();
		int col = gameState.whoseTurn().getUnitLastClicked().getCol();
		
		// ## play the effect on that tile
		EffectAnimation effect = null;
		if (this.getCardConfPath().equals(StaticConfFiles.c_entropic_decay)){
			effect = BasicObjectBuilders.loadEffect(StaticConfFiles.f1_martyrdom);	// ## -> destroy any units ? 
		} else if (this.getCardConfPath().equals(StaticConfFiles.c_truestrike)) {
			effect = BasicObjectBuilders.loadEffect(StaticConfFiles.f1_inmolation);
		}
		BasicCommands.playEffectAnimation(out, effect, gameState.getCell(row, col).getBottomTile());
		
		// ## send "spell cast" event to that cell
		gameState.getCell(row, col).innerEventProcessor(gameState.whoseTurn().getUnitLastClicked(), InnerEventType.SPELL_CAST, out, gameState);
		
		// ## ability triggered
		abilityLauncher.launchAbility();
		
		// ## refresh mana
		int newMana = gameState.whoseTurn().getPlayer().getMana() - this.getManacost();
		newMana = newMana > 0 ? newMana : 0; // ## !only for test, comment this when running
		gameState.whoseTurn().getPlayer().setMana(newMana);
		if (gameState.whoseTurn().getPlayer() instanceof AiPlayer) BasicCommands.setPlayer2Mana(out, gameState.whoseTurn().getPlayer());
		else BasicCommands.setPlayer1Mana(out, gameState.whoseTurn().getPlayer());
		
		// ## clean up
		cardDeployedCleanUp(out, gameState);
		return;
	}
}

package structures.basic;

import akka.actor.ActorRef;
import commands.BasicCommands;
import structures.GameState;

public class AvatarUnit extends OperatableUnit {

	public AvatarUnit() {
		super();
		this.setAttack(2);
		this.setHealth(20);
		this.priorityLevel = AttackPriority.AVATAR;
	}

	// Assignee: the Avatar sysnchronized healing is implemented by @Yaqi Wang and @Xinyu Tian, together with the helper methods.
	@Override
	public void gainAttack(ActorRef out, GameState gameState, int deltaAttack) {
		super.gainAttack(out, gameState, deltaAttack);
	}
	
	@Override
	public void gainHealth(ActorRef out, GameState gameState, int deltaHealth) {
		super.gainHealth(out, gameState, deltaHealth);
		this.getPlayer().setHealth(this.getHealth());
		BasicCommands.setPlayer1Health(out, this.getPlayer());
	}
	
	@Override
	/**The method deal damage both to avatar unit and its player by accepting damage from an enemy unit*/
	public void damagedBy(ActorRef out, Unit attacker) {
		// ## deal with unit damage and player damage
		this.damagedBy(out, ((OperatableUnit) attacker).getAttack());
		System.out.printf("after being attacked, I, %s, now has health of %d\n", this.getClass(), this.getHealth());
		// GameOver() logic
	}

	@Override
	public void damagedBy(ActorRef out, int damage) {
		BasicCommands.playUnitAnimation(out, this, UnitAnimationType.hit);
		try {Thread.sleep(1200);} catch (Exception e) {e.printStackTrace();}
		
		// ## set unit health firstly
		this.setHealth(this.getHealth() - damage > 0 ? this.getHealth() - damage : 0);

		// ## set unit health visually
		BasicCommands.setUnitHealth(out, this, this.health);
		
		// ## set player health secondly
		this.getPlayer().setHealth(this.health);
		
		// ## set player health visually
		if (this.getPlayer() instanceof HumanPlayer)
			BasicCommands.setPlayer1Health(out, getPlayer());
		else 
			BasicCommands.setPlayer2Health(out, getPlayer());
	}
	

}

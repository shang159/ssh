package structures.basic;

public class HandCard extends Card {

	private String cardConfPath;
	private int prevHandPosition; // ## record the position of last time showed in hand
	private AbilityType abilityType;
	
	public static enum AbilityType {
		ON_TIME_SPELL,
		TRIGGERED,
		BUILT_IN,
		BUILT_IN_AND_TRIGGERED;
	}
	
	public HandCard() {
		super();
		this.cardConfPath = null;
		this.prevHandPosition = -1;
		this.abilityType = null;
	}

	/**Return the configuration file which the card is depending on*/
	public String getCardConfPath() {
		return this.cardConfPath;
	}
	
	/**Call this method immediately after you use BasicCommands.loadCard, e.g., Hand.class: addCard()*/
	public void setCardConfPath(String newCardConfPath) {
		this.cardConfPath = newCardConfPath;
	}

	/**Return the hand position where the card was in hand*/
	public int getPrevHandPosition() {
		return this.prevHandPosition;
	}
	
	/**Call this method immediately after you added it to hand, e.g., Hand.class: addCard()*/
	public void setPrevHandPosition(int newHandPosition) {
		this.prevHandPosition = newHandPosition;
	}
	
	/**Return the ability type of this card in Enum AbilityType*/
	public AbilityType getAbilityType() {
		return this.abilityType;
	}
	
	/**Call this method immediately after you added it to hand, e.g., Hand.class: addCard()*/
	public void setAbilityType(AbilityType abilityType) {
		this.abilityType = abilityType;
	}
	
	/**Check card type based on its health. A unit card always has a health above 0*/
	public boolean isUnitCard() {
		return this.getBigCard().getHealth() > 0 ? true : false;
	}
	
	/**Check card type based on its health. A spell card always has a health below 0*/
	public boolean isSpellCard() {
		return this.getBigCard().getHealth() < 0 ? true : false;
	}
	
	@Override
	public String toString() {
		String cardInfo = "";
		cardInfo += String.format("=== Card Type:\t%s\n", this.getClass());
		cardInfo += String.format("=== Card Name:\t%s\n", this.getCardname());
		cardInfo += String.format("=== Conf Path:\t%s\n", this.getCardConfPath());
		cardInfo += String.format("=== Ability:\t%s\n", this.getAbilityType());
		cardInfo += String.format("=== Mana Cost:\t%s", this.getManacost());
		return cardInfo;
	}
}

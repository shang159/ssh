package structures.basic;

import akka.actor.ActorRef;
import structures.GameState;

/**functional interface for implementing AI strategy*/
public interface SelfGovernable {

	public void strategyApplied(ActorRef out, GameState gameState);
}

package structures.basic;

import java.util.LinkedList;

import structures.GameElementSet;

public class Deck {

	private GameElementSet owner;
	private LinkedList<String> cardConfPathStack; // ## simulating a stack
	
	public Deck(LinkedList<String> deck) {
		this.owner = null;
		this.cardConfPathStack = deck;
	}

	public void setOwner(GameElementSet owner) {
		this.owner = owner;
	}
	
	public int getOwnerGesID() {
		return this.owner.getGesID();
	}
	
	public int getRemainingCardsNum() {
		return this.cardConfPathStack.size();
	}
	
	public boolean hasCard() {
		return !cardConfPathStack.isEmpty();
	}
	
	/**Pop the top cardConfPath (String) in the stack and return null if the deck is empty*/
	public String popCard() {
		String nextCardConfPath = null;
		if (!this.cardConfPathStack.isEmpty()) {
			nextCardConfPath = this.cardConfPathStack.pop();
		} else {
			System.out.println("[Game Lose] - Your deck is empty");
		}
		return nextCardConfPath;
	}
	
}

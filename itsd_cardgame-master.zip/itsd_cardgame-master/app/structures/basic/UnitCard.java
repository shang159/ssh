package structures.basic;

import java.util.LinkedList;

import akka.actor.ActorRef;
import structures.GameState;
import structures.basic.SpellCard.SpellRangeGenerator;
import utils.StaticConfFiles;
/**this class will only implement unit summon ranging function*/
public class UnitCard extends HandCard {

	
	public UnitCard() {
		super();
	}
	
	interface UnitRangeGenerator {
		LinkedList<int[]> generateRange();
	}
	
	// Assignee: the summon ranging is implemented by @Xinyu Tian, together with the helper methods.
	public LinkedList<int[]> unitShowSummonTile(ActorRef out, GameState gameState) {
		UnitRangeGenerator rangeGenerator = () -> {
			LinkedList<int[]> range = new LinkedList<>();
			
			if (this.getCardConfPath().equals(StaticConfFiles.c_planar_scout)
					|| this.getCardConfPath().equals(StaticConfFiles.c_ironcliff_guardian)) {
				// ## airdrop
				range = gameState.whoseTurn().scanUnitInBoard(gameState, false, true);
			} else {
				// ## normal summon
				range = gameState.whoseTurn().scanTileInBoard(gameState);
			}
			
			if (gameState.whoseTurn().getPlayer() instanceof HumanPlayer) {
				range.forEach(pos -> gameState.getCell(pos[0], pos[1]).displayWithMode(out, 1));
				try { Thread.sleep(240);} catch (Exception e) {e.printStackTrace();}
				gameState.whoseTurn().addRangeActivated(range);
			}
			
			return range;
		};
		
		var range = rangeGenerator.generateRange();
		return range;
	}
}

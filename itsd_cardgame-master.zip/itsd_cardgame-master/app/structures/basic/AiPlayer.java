package structures.basic;

import akka.actor.ActorRef;
import structures.GameState;

public class AiPlayer extends Player {

	String aiName;
	private boolean cardDeployAvailable;
	private boolean unitMoveAvailable;
	private boolean unitAttackAvailable;
	public AiPlayer() {
		super();
		this.aiName = "_robot_001";
		cardDeployAvailable = true;
		unitMoveAvailable = true;
		unitAttackAvailable = true;
	}
	
	public AiPlayer(String aiName) {
		super();
		this.aiName = aiName;
	}
	
	public String getName() {
		return this.aiName;
	}

	/**strategy 1 - deploy cards as many as possible*/
	public boolean ableToDeployCard() {
		return this.cardDeployAvailable;
	}
	
	public void cardDeployPerformed(ActorRef out, GameState gameState) {
		
		this.cardDeployAvailable = false;
	}
	
	/**strategy 2 - attack if it can*/
	public boolean ableToAttack() {
		return this.unitAttackAvailable;
	}
	
	public void unitAttackPerformed() {
		this.unitAttackAvailable = false;
	}
	
	/**strategy 3 - move if it can*/
	public boolean ableToMove() {
		return this.unitMoveAvailable;
	}
	
	public void unitMovePerformed() {
		this.unitMoveAvailable = false;
	}
	
	
	public void strategyReset() {
		this.cardDeployAvailable = true;
		this.unitMoveAvailable = true;
		this.unitAttackAvailable = true;
	}
	
	@Deprecated
	public static synchronized void threadTest(GameState gameState) {
		try { Thread.sleep(12000);} catch (Exception e) {e.printStackTrace();}
		System.out.println("flipping" + gameState.isPlayer1Turn());
		gameState.endWhoseverTurn();
		System.out.println("flipped" + gameState.isPlayer1Turn());
	}
}

package structures;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedList;
import java.util.Queue;

import structures.basic.Deck;

import java.io.File;
import java.io.IOException;

import utils.StaticConfFiles;

public class DeckGenerator {

	private final ArrayList<String> cardsPool;
	private static final int MAX_CARDS_PER_DECK = 20;
	
	public DeckGenerator() {
		cardsPool = new ArrayList<>();
		
		// ## pre-defined deck1
		cardsPool.add(StaticConfFiles.c_azure_herald);			// #0
		cardsPool.add(StaticConfFiles.c_azurite_lion);			// #1
		cardsPool.add(StaticConfFiles.c_comodo_charger);		// #2
		cardsPool.add(StaticConfFiles.c_fire_spitter);			// #3
		cardsPool.add(StaticConfFiles.c_hailstone_golem);		// #4 !! shared card
		cardsPool.add(StaticConfFiles.c_ironcliff_guardian);	// #5
		cardsPool.add(StaticConfFiles.c_pureblade_enforcer);	// #6
		cardsPool.add(StaticConfFiles.c_silverguard_knight);	// #7
		cardsPool.add(StaticConfFiles.c_sundrop_elixir);		// #8
		cardsPool.add(StaticConfFiles.c_truestrike);			// #9
		
		// ## pre-defined deck2
		cardsPool.add(StaticConfFiles.c_blaze_hound);			// #10
		cardsPool.add(StaticConfFiles.c_bloodshard_golem);		// #11
		cardsPool.add(StaticConfFiles.c_entropic_decay);		// #12
		cardsPool.add(StaticConfFiles.c_hailstone_golem);		// #13 !! shared card
		cardsPool.add(StaticConfFiles.c_planar_scout);			// #14
		cardsPool.add(StaticConfFiles.c_pyromancer);			// #15
		cardsPool.add(StaticConfFiles.c_serpenti);				// #16
		cardsPool.add(StaticConfFiles.c_rock_pulveriser);		// #17
		cardsPool.add(StaticConfFiles.c_staff_of_ykir);			// #18
		cardsPool.add(StaticConfFiles.c_windshrike);			// #19
	}

	// ## factory pattern
	public static Deck[] generateDecks(boolean mixEnable) {
		DeckGenerator dg_default = new DeckGenerator();
		Deck[] decks = new Deck[2];
		if (!mixEnable) {	// ## Deck1 = 1.* series
			Deck deck1 = new Deck( dg_default.generatePreDefDeck1(dg_default.getCardsPool()) );
			Deck deck2 = new Deck( dg_default.generatePreDefDeck2(dg_default.getCardsPool()) );
			decks[0] = deck1;
			decks[1] = deck2;
		} else {			// ## Deck1 = fully mixed 20 cards, disabled for now
			Deck deck1 = new Deck( dg_default.generateMixedDecks(dg_default.getCardsPool()).get(0) );
			Deck deck2 = new Deck( dg_default.generateMixedDecks(dg_default.getCardsPool()).get(1) );
			decks[0] = deck1;
			decks[1] = deck2;
		}
		return decks;
	}
	
	
	
	// ## ===================================================== ## //
	private ArrayList<String> getCardsPool() {
		return this.cardsPool;
	}
	
	// ## generate pre-defined deck1
	private LinkedList<String> generatePreDefDeck1(ArrayList<String> cardsPool) {
		LinkedList<String> deck = new LinkedList<>();
		for (int i = 0; i < MAX_CARDS_PER_DECK; i++) {
			deck.add(cardsPool.get(i % 10));
		}

		Collections.shuffle(deck);
		return deck;
	}
	
	// ## generate pre-defined deck2
	private LinkedList<String> generatePreDefDeck2(ArrayList<String> cardsPool) {
		LinkedList<String> deck = new LinkedList<>();
		for (int i = 0; i < MAX_CARDS_PER_DECK; i++) {
			deck.add(cardsPool.get(10 + i % 10)); // ## for deck2: 10 + i % 10
		}

		Collections.shuffle(deck);
		return deck;
	}
	
	// ## generate decks mixing all cards together
	private ArrayList<LinkedList<String>> generateMixedDecks(ArrayList<String> cardsPool) {
		ArrayList<String> mixedCardsPool = new ArrayList<>();
		mixedCardsPool.addAll(cardsPool);
		
		Collections.shuffle(mixedCardsPool);
		
		LinkedList<String> deck1 = generatePreDefDeck1(mixedCardsPool);
		LinkedList<String> deck2 = generatePreDefDeck2(mixedCardsPool);
		ArrayList<LinkedList<String>> array = new ArrayList<>();
		array.add(deck1);
		array.add(deck2);
		return array;
		
	}
	
}

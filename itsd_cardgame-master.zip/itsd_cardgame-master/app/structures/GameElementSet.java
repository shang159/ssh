package structures;

import java.awt.datatransfer.Clipboard;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.Objects;
import java.util.Set;

import org.apache.commons.logging.LogFactory;
import org.checkerframework.checker.units.qual.A;

import akka.actor.ActorRef;
import commands.BasicCommands;
import structures.basic.AiPlayer;
import structures.basic.AvatarUnit;
import structures.basic.Card;
import structures.basic.Cell;
import structures.basic.Deck;
import structures.basic.EffectAnimation;
import structures.basic.Hand;
import structures.basic.HandCard;
import structures.basic.HumanPlayer;
import structures.basic.OperatableUnit;
import structures.basic.Player;
import structures.basic.SelfGovernable;
import structures.basic.SpellCard;
import structures.basic.Tile;
import structures.basic.Unit;
import structures.basic.UnitCard;
import utils.BasicObjectBuilders;
import utils.StaticConfFiles;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

/**
 * This class is one of the CORE design for our implementation.
 * it aggregates player, turn, deck, hand, and the related operation.
 * 
 *  Main functions provided by this class is listed below:
 *  
 *  1. Supplement cards.
 *  2. Deployment.
 *  3. Move.
 *  4. AI strategy.
 * */
public class GameElementSet implements SelfGovernable {
	final Logger log = LoggerFactory.getLogger(this.getClass());
	
	private int gesID;	// ## 1 -> player on the left; 2 -> player on the right
	public Player player;
	public Class<? extends Player> playerType;
	private Deck deck;
	private Hand hand;
	private Turn turn;
	private boolean turnStarted;
	private Unit avatar;
	private boolean operationSyn = false;
	
	// ## record
	private Unit unitLastClicked;
	private Card cardOnHold;
	private LinkedList<int[]> rangeActivated;
	
	// ## id generator
	private static int globalGesID = 0;
	private static int globalUnitID = 0;
	
	public static final int MAX_MANA = 9;
	
	public GameElementSet(Player aPlayer, Deck aDeck, Hand aHand, String anAvatar) {
		this.gesID = ++globalGesID;
		
		this.player = aPlayer;
		this.playerType = aPlayer.getClass();	// initialize problem
		
		this.deck = aDeck;
		this.deck.setOwner(this);
		
		this.hand = aHand;
		this.hand.setOwner(this);
		
		this.turn = null;
		this.turnStarted = false;
		
		this.avatar = BasicObjectBuilders.loadUnit(anAvatar, globalUnitID++, AvatarUnit.class);
		((AvatarUnit) avatar).setPlayer(aPlayer);
		
		this.unitLastClicked = null;
		this.cardOnHold = null;
		this.rangeActivated = new LinkedList<>();
		
		// ## tested
		System.out.printf("[Avatar created] - this Player from %s has created %d units with latest avatar id = %d\n",
				this.player.getClass(),
				globalUnitID,
				this.avatar.getId());
	}

	public int getGesID() {
		return this.gesID;
	}
	
	public Player getPlayer() {
		return this.player;
	}
	
	public Unit getAvatarUnit() {
		return this.avatar;
	}
	
	// ## =========================== turn-related operation ========================
	// Assignee: the mana gain is implemented by @Yingbo Ge and @You Li, together with the helper methods.
	/**Automatically assign a Turn() to this GES and set Player's mana according to the turn index*/
	public void takeMyTurn(GameState gameState) {
		this.turn = new Turn();
		
		// ## set up mana
//		if (Turn.globalTurnIndex % 2 == 1) {
//			turnIndex = 1 + Turn.globalTurnIndex / 2;	// ## mapping global turn 1, 3, 5 -> local turn 1, 2, 3
//		} else if (Turn.globalTurnIndex % 2 == 0) {
//			turnIndex = 0 + Turn.globalTurnIndex / 2;	// ## mapping global turn 2, 4, 6 -> local turn 1, 2, 3
//		} -> equals to:
		int localTurnIndex = Turn.globalTurnIndex % 2 + Turn.globalTurnIndex / 2;
		int trimmedMana = localTurnIndex + 1 <= MAX_MANA ? localTurnIndex + 1 : MAX_MANA; // ## limited mana capacity 
		this.player.setMana(trimmedMana); 	// ## 2, 3, ..., 8, 9, 9, ...
		
		// ## reset chances and strategy
		this.resetUnitChancesInTurn(gameState);
		if (this.player instanceof AiPlayer) ((AiPlayer) this.player).strategyReset();
		
		this.turnStarted = true;
	}
	
	private void resetUnitChancesInTurn(GameState gameState) {
//		System.out.println("resetting...");
		var units = scanUnitInBoard(gameState, false, false);
		
//		units.forEach(pos -> System.out.printf("resetting...[%d][%d]\n", pos[0], pos[1]));
		units.forEach( pos -> ((OperatableUnit) gameState.getCell(pos[0], pos[1]).getSurfaceUnit()).regainChance());
	}

	/**The method flip the turn status by setting it to false if it was true*/
	public void endTurn() {
		if (this.turnStarted) {
			this.turnStarted = false;
			this.turn = null;
		}
	}
	
	/**Return true if it is this GES's turn; Otherwise return false*/
	public boolean turnIsStarted() {
		return this.turnStarted;
	}
	
	/**Called by event [heartbeat] processor. The method will count down 90 seconds for each turn*/
	public boolean receiveHeartBeat() {
		boolean overTime = false;
		if (this.turn != null) {
			System.out.printf("/--> Player[%s]'s turn remains: %.1f seconds\r", this.player.getClass(), this.turn.getRemainingSecs());
			overTime = this.turn.decreaseTime();
		}
		return overTime;
	}
	
	// ## ====================== recorder-related operation ========================
	/**Record the unit just clicked*/
	public void setUnitLastClicked(Unit unit) {
		this.unitLastClicked = unit;
	}
	
	/**Return the unit clicked for last time*/
	public Unit getUnitLastClicked() {
		return this.unitLastClicked;
	}
	
	/**Record the card Player just clicked, or set to NULL if the Player cancelled*/
	public void setCardOnHold(Card cardOnHold) {
		this.cardOnHold = cardOnHold;
	}
	
	/**Return the card entity the Player just clicked, or return NULL if the Player hasn't clicked a card*/
	public Card getCardOnHold() {
		return this.cardOnHold;
	}
	
	// ## ===================== ranging-related operation ========================
	/**Record the activated display range to make next-time display cancellation easier*/
	public void addRangeActivated(LinkedList<int[]> rangeActivated) {
		if (this.rangeActivated == null)
			this.rangeActivated = rangeActivated;
		else
			this.rangeActivated.addAll(rangeActivated);
	}
	
	/**Return the latest activated display range of this game element set*/
	public LinkedList<int[]> getRangeActivated() {
		return this.rangeActivated;
	}
	
	/**Undo all highlighted range since the last activation*/
	public void clearRangeActivated(ActorRef out, GameState gameState) {
		if (this.rangeActivated != null) {
			this.rangeActivated.forEach(pos -> gameState.getCell(pos[0], pos[1]).displayWithMode(out, 0));
			try {Thread.sleep(120);} catch (Exception e) {e.printStackTrace();};
			this.rangeActivated = null;
		} else {
			log.warn("range is already clear or has not been recorded");
		}
	}
	
	// ## ==================== card-related operation=======================
	// Assignee: the drawing function is implemented by @Yingbo Ge and @Xinyu Tian, together with the helper methods.
	/**Add one single card from Deck to Hand logically and synchronously add it to the front-end*/
	public void supplementSingleCard(ActorRef out) {
		String cardConfPath = this.deck.popCard();
		if (cardConfPath == null) {
			
			// ## lose the game if no cards in deck (?)
			log.warn("[Game Lose - Out of Deck] no more cards in deck to play");
		} else {
			
			// ## step 1 - logically add card to hand. Method will add it in string and register it with a hashmap to a Card object. 
			this.hand.addCard(cardConfPath);
			
			// ## step 2 - visually display the card to front-end in human'view
			if (this.getPlayer() instanceof HumanPlayer)
				this.hand.displayCard(out, hand.getLastAddedHandPosition(), 0, false);
			
			log.info(String.format("[Card supplemented] deck[%d] remains %d cards", this.deck.getOwnerGesID(), this.deck.getRemainingCardsNum()));
		}
	}
	
	// Assignee: the playing cards is implemented by @Xinyu Tian, together with the helper methods.
	/**Call this function in the TileClicked events to actually deploy card into tile(cell)*/
	public void deployCardToCell(ActorRef out, GameState gameState, Cell targetedCell) {		
		try {
			// ## preparation: clear the existing range display
			gameState.whoseTurn().clearRangeActivated(out, gameState);
			
			// ## play the summon animation
			EffectAnimation effect = BasicObjectBuilders.loadEffect(StaticConfFiles.f1_summon);
			BasicCommands.playEffectAnimation(out, effect, targetedCell.getBottomTile());
			
			// ## step 1 - hold the card
			Card card = gameState.whoseTurn().getCardOnHold();
			if (card == null) throw new GameException("No cards on hold currently");
			
			// ## step 2 - build unit and setup it with card's health and attack
			String unitConfPath = this.hand.convert2UnitConfPath(((HandCard) card).getCardConfPath());			
			Unit unit = BasicObjectBuilders.loadUnit(unitConfPath, globalUnitID++, OperatableUnit.class); // ! serious unit id problem
			((OperatableUnit) unit).setInnerCard(card);
			((OperatableUnit) unit).setPlayer(this.getPlayer());
			
			// ## step 3 - turn to cell to actually deploy on board
			targetedCell.setupNewUnit(unit, out, gameState);
			
			// ## refresh mana
			int newMana = this.player.getMana() - card.getManacost();
			newMana = newMana > 0 ? newMana : 0; // ## !only for test, comment this when running
			this.player.setMana(newMana);
			if (this.player instanceof AiPlayer) 
				BasicCommands.setPlayer2Mana(out, this.player);
			else 
				BasicCommands.setPlayer1Mana(out, this.player);
			
			// ## clean up: delete the card from hand's view
			gameState.whoseTurn().deleteDeployedCardFromHand(out);
			try {Thread.sleep(1200);} catch (Exception e) {e.printStackTrace();}
		} catch (GameException e) { e.printStackTrace(); }
	}
	
	/**call this method when human player clicked a card and want to know the info of the card entity*/
	public Card getCardFromHand(int handPosition) {
		try {
			return this.hand.getCardEntity(handPosition);
		} catch (GameException e) {
			e.printStackTrace();
			return null;
		}
	}
	
	/**Logically and visually delete a card in hand*/
	public boolean deleteCardFromHand(ActorRef out, int handPosition) {
		this.hand.deleteCard(handPosition);					// ## logically delete the card
		
		if (this.player instanceof HumanPlayer)
			this.hand.displayCard(out, handPosition, 0, true); 	// ## set flag $deletion = true;
		
		return true;
	}
	
	/**Called by TileClicked or CardClicked event processor to delete the card just deployed*/
	public void deleteDeployedCardFromHand(ActorRef out) {
		Card card = Objects.requireNonNull(this.getCardOnHold(), "You haven't deployed a card yet");
		int handPosition = ((HandCard) card).getPrevHandPosition();
		if (handPosition > 0 && handPosition <= 6) {
			deleteCardFromHand(out, handPosition);
			this.cardOnHold = null;
		} else {
			log.error("Illegal hand position given, cannot delete the card. operation is missing");
		}
	}
	
	// Assignee: the move is implemented by @Yueyue Liu and @Yaqi Wang, together with the helper methods.
	/**the method move the unit which any player clicked last time to the destination Cell(or tile).
	 * Call this method when conduct movement in tileClicked or move-then-attack strategy*/
	public void moveUnitToCell(ActorRef out, GameState gameState, Cell targetedCell) {
		
		// ## <moving is an atomic operation, lock up>
		Lock lock = new ReentrantLock();
		lock.lock();
		
		// ## undo the highlight firstly
		gameState.whoseTurn().clearRangeActivated(out, gameState);
		try {Thread.sleep(240);} catch (Exception e) {e.printStackTrace();}
		
		// ## get all paras needed to conduct move
		Tile destination = targetedCell.getBottomTile();
		Unit unitToBeMoved = gameState.whoseTurn().getUnitLastClicked();
		Cell departure = gameState.getCell(unitToBeMoved.getRow(), unitToBeMoved.getCol());
		
		int steps = Math.abs(unitToBeMoved.getRow() - destination.getTiley()); 		// ## animation time correction
		steps += Math.abs(unitToBeMoved.getCol() - destination.getTilex());			// ## animation time correction
		log.info(String.format("unit moving...wait for %d ms\n", steps * 1100));	// ## one single step takes 1.1 seconds
		
		BasicCommands.moveUnitToTile(out, unitToBeMoved, destination);
		try { Thread.sleep(steps * 1100); } catch (Exception e) { e.printStackTrace(); }
		
		departure.cleanUpStoppedGhost(out, gameState); 					// smoother new try @28 Jun
		targetedCell.setupStoppedUnit(unitToBeMoved, out, gameState); 	// smoother new try @28 Jun
		
		lock.unlock();
		// ## </lock release>
	}
	
	/**call the method when implementing auto move-attack range detection
	 * @param moveRange : that a unit can move; adjacentRange = range that the unit should be attacked
	 * @param adjacentRange : vicinity of the given unit*/
	public LinkedList<int[]> intersection(LinkedList<int[]> moveRange, LinkedList<int[]> adjacentRange) {
		LinkedList<int[]> stand = new LinkedList<int[]>();
		
		var iterMain = moveRange.iterator();
		while (iterMain.hasNext()) {
			int[] posMain = iterMain.next();
			
			// ## compare to adjacent Range
			var iterSub = adjacentRange.iterator();
			while (iterSub.hasNext()) {
				int[] posSub = iterSub.next();
				
				if ( Arrays.equals(posMain, posSub) )
					stand.add(posMain);
			}
			
		}
		return stand;
	}
	
	/* ===============================Range related methods=================================
	 * getMoveRangeAround:
	 * -> accept one or more cell positions
	 * -> validate positions(boundary, units owner)
	 * 	->the tile which being clicked has satisfied the pre-conditions of:
	 * 		a). in my turn
	 * 		b). clicked on tile with unit
	 * 		c). my unit
	 * 		d). movable
	 * 		-> out of boundary validation
	 * 		-> unit blocked validation
	 * -> return many positions
	 */
	/**Return valid tiles that a unit at[row, col] can move to*/
	public LinkedList<int[]> getMoveRangeAround(int row, int col, GameState gameState) {
		/*
		 * 						(r-2, c)
		 * 			(r-1, c-1)	(r-1, c)	(r-1, c+1)
		 * (r, c-2) (r,   c-1) 	(r,   c) 	(r,   c+1) 	(r, c+2)
		 * 			(r+1, c-1)	(r+1, c)	(r+1, c+1)
		 * 						(r+2, c)
		 */
		LinkedList<int[]> filteredRange = new LinkedList<>();
		
		// ## (@Yueyue Liu version filter)  - Vicinity and Blocking Checker
		// ## right block filter. 
		// ## (r,c) -> unit -> (r, c+2), then (r, c+2) is BLOCKED by unit
		if ( gameState.getCell(row, col + 1)!= null && !(gameState.getCell(row, col + 1).tileHasUnit()) ) {
				filteredRange.add(new int[] {row, col + 1});
				if ( gameState.getCell(row, col + 2) != null && !gameState.getCell(row, col + 2).tileHasUnit())
					filteredRange.add(new int[] {row, col + 2});
		}
		
		// ## left block filter.
		// ## (r, c-2) <- unit <- (r,c), then (r, c-2) is BLOCKED by unit
		if ( gameState.getCell(row, col - 1)!= null && !(gameState.getCell(row, col - 1).tileHasUnit()) ) {
			filteredRange.add(new int[] {row, col - 1});
			if ( gameState.getCell(row, col - 2) != null && !gameState.getCell(row, col - 2).tileHasUnit())
				filteredRange.add(new int[] {row, col - 2});
		}
		
		/*
		 * ## top block filter
		 *	(r+2, c), then (r+2, c) is BLOCKED by unit
		 *	|
		 * 	unit
		 * 	|
		 * 	(r, c)
		 */
		if ( gameState.getCell(row + 1, col)!= null && !(gameState.getCell(row + 1, col).tileHasUnit()) ) {
			filteredRange.add(new int[] {row + 1, col});
			if ( gameState.getCell(row + 2, col) != null && !gameState.getCell(row + 2, col).tileHasUnit())
				filteredRange.add(new int[] {row + 2, col});
		}
		
		/*
		 * ## bottom block filter
		 * 	(r, c)
		 * 	|
		 * 	unit
		 * 	|
		 * 	(r-2, c), then (r-2, c) is BLOCKED by unit
		 */
		if ( gameState.getCell(row - 1, col)!= null && !(gameState.getCell(row - 1, col).tileHasUnit()) ) {
			filteredRange.add(new int[] {row - 1, col});
			if ( gameState.getCell(row - 2, col) != null && !gameState.getCell(row - 2, col).tileHasUnit())
				filteredRange.add(new int[] {row - 2, col});
		}
		
		/*
		 * ## top-left CORNER blocked filter
		 * (r-1, c-1) - unit
		 * 		|		|
		 * 		unit - (r, c)
		 * 
		 * then (r-1, c-1) is blocked
		 */
		if (	gameState.getCell(row - 1, col - 1) !=null 
				&& !gameState.getCell(row - 1, col - 1).tileHasUnit()
				&& ((gameState.getCell(row, col - 1) != null && !gameState.getCell(row, col - 1).tileHasUnit())
				|| (gameState.getCell(row - 1, col) != null && !gameState.getCell(row - 1, col).tileHasUnit())
				)) {
			filteredRange.add(new int[] {row - 1, col - 1}); // ## tested -> valid
		}
		
		/*
		 * ## top-right CORNER blocked filter
		 * 		unit - 	(r-1, c+1)
		 * 		|		|
		 * 		(r,c) - unit
		 * 
		 * then (r-1, c+1) is blocked
		 */
		if (	gameState.getCell(row - 1, col + 1) != null
				&& !gameState.getCell(row - 1, col + 1).tileHasUnit()
				&& ((gameState.getCell(row, col + 1) != null && !gameState.getCell(row, col + 1).tileHasUnit())
				|| (gameState.getCell(row - 1, col) != null && !gameState.getCell(row - 1, col).tileHasUnit())
				)) {
			filteredRange.add(new int[] {row - 1, col + 1}); // ## tested -> valid			
		}
		
		/*
		 * ## bottom-left CORNER blocked filter
		 * 		unit - 	  (r, c)
		 * 		|			 |
		 * 		(r+1, c-1)- unit
		 * 
		 * then (r+1, c-1) is blocked
		 */
		if (	gameState.getCell(row + 1, col - 1) != null
				&& !gameState.getCell(row + 1, col - 1).tileHasUnit()
				&& ((gameState.getCell(row + 1, col) != null && !gameState.getCell(row + 1, col).tileHasUnit())
				|| (gameState.getCell(row, col - 1) != null && !gameState.getCell(row, col - 1).tileHasUnit())
				)) {
			filteredRange.add(new int[] {row + 1, col - 1}); // ## tested -> valid
		}
		
		/*
		 * ## bottom-right CORNER blocked filter
		 * 		(r, c) - unit
		 * 		|			|
		 * 		unit - 	(r+1, c+1)
		 * 
		 * then (r+1, c+1) is blocked
		 */
		if (	gameState.getCell(row + 1, col + 1) != null 
				&& !gameState.getCell(row + 1, col + 1).tileHasUnit()
				&& ((gameState.getCell(row + 1, col) != null && !gameState.getCell(row + 1, col).tileHasUnit())
				|| (gameState.getCell(row, col + 1) != null && !gameState.getCell(row, col + 1).tileHasUnit())
				)) {
			filteredRange.add(new int[] {row + 1, col + 1}); // ## tested -> valid
		}
		
		return filteredRange;
	}
	
	/**return spots for ranged attack*/
	public LinkedList<int[]> getRemoteRangeAround(GameState gameState, boolean scanForEnemy) {
		return scanUnitInBoard(gameState, scanForEnemy, false);
	}
	
	/**Return valid tiles around the [row, col].
	 * for ranged attack, set flag $ranged = [true]
	 * for friend units deployement, set flag $scanForEnemy = [false]*/
	public LinkedList<int[]> getAdjacentRangeAround(int row, int col, GameState gameState, boolean scanForEnemy) {
		/*
		 * 			(r-1, c-1)	(r-1, c)	(r-1, c+1)
		 * 			(r,   c-1) 	(r,   c) 	(r,   c+1) 	
		 * 			(r+1, c-1)	(r+1, c)	(r+1, c+1)
		 */
		LinkedList<int[]> rawRange = new LinkedList<>();
		rawRange.add(new int[] {row - 1, col - 1});
		rawRange.add(new int[] {row - 1, col});
		rawRange.add(new int[] {row - 1, col + 1});
		
		rawRange.add(new int[] {row, col - 1});	
		rawRange.add(new int[] {row, col + 1});
		
		rawRange.add(new int[] {row + 1, col - 1});
		rawRange.add(new int[] {row + 1, col});
		rawRange.add(new int[] {row + 1, col + 1});
		
		// ## validate
		var iter = rawRange.iterator();
		while (iter.hasNext()) {
			int[] pos = iter.next();
			int nextRow = pos[0];
			int nextCol = pos[1];
			
			if ( (nextRow < 0 || nextRow > 4) || (nextCol < 0 || nextCol > 8) ) {
				// ## boundary check
				iter.remove();
				continue;
			}
			
			// ## flag check
			if ( scanForEnemy && ! (gameState.getCell(nextRow, nextCol).tileHasUnit()) ) { 
				
				// ## find enemy adjacent units - remove those don't have units on it
				iter.remove();
			} else if (scanForEnemy && gameState.getCell(nextRow, nextCol).tileHasUnit()) {
				
				// ## find enemy adjacent units - remove those have units but are friend units
				if ( ((OperatableUnit) gameState.getCell(nextRow, nextCol).getSurfaceUnit()).getPlayer()
						== this.getPlayer())
					iter.remove();
			} else if (!scanForEnemy && gameState.getCell(nextRow, nextCol).tileHasUnit()) {
				
				// ## find friend adjacent tiles - remove those have units on it
				iter.remove();
			}
		}
		return rawRange;
	}
	
	/**Scan available units on the board for spell to be deployed, including friend and enemy units.
	 * for buff-spell, set flag $scanForEnemy to [false]. for debuff-spell, set it to true
	 * for airdrop units, set flag #scanForAirDrop to [true]*/
	public LinkedList<int[]> scanUnitInBoard(GameState gameState, boolean scanForEnemy, boolean scanForAirDrop) {
		LinkedList<int[]> rawRange = new LinkedList<>();
		// ## scanning the entire board
		for (int i = 0; i < GameState.TOTAL_ROWS; i++)
			for (int j = 0; j < GameState.TOTAL_COLS; j++) {
				if ( gameState.getCell(i, j).tileHasUnit() && !scanForAirDrop) {
					if ( scanForEnemy 
							&& ((OperatableUnit) gameState.getCell(i, j).getSurfaceUnit()).getPlayer()
							!= this.getPlayer()) {
						rawRange.add(new int[] {i, j});
						log.info(String.format("ranged targets detected at tile[%d][%d]", i, j));
					} else if ( !scanForEnemy
							&& ((OperatableUnit) gameState.getCell(i, j).getSurfaceUnit()).getPlayer()
							== this.getPlayer()) {
						rawRange.add(new int[] {i, j});
						log.debug(String.format("friend deploment detected at tile[%d][%d]", i, j));
					}
				} else if (!gameState.getCell(i, j).tileHasUnit() && scanForAirDrop) {
					rawRange.add(new int[] {i, j});
				}
			}
		return rawRange;
	}
	
	/**Scan available tiles on the board for friend units to be deployed.
	 * This method re-use the getAdjacentRangeAround() function inside GameElementSet
	 * by setting flag: $ranged = [false], $scanForEnemy = [false]*/
	public LinkedList<int[]> scanTileInBoard(GameState gameState) {
		LinkedList<int[]> friendUnits = scanUnitInBoard(gameState, false, false);
		LinkedList<int[]> deployAvailable = new LinkedList<>();
		Set<int[]> deploySet = new HashSet<>();
		
		for (var pos : friendUnits) 
			deploySet.addAll(getAdjacentRangeAround(pos[0], pos[1], gameState, false));
		
		deployAvailable.addAll(deploySet);
		return deployAvailable;
	}
	
	@Override
	/**call the method when applying ai logic in ai's turn*/
	public void strategyApplied(ActorRef out, GameState gameState) {
		if ( !(this.getPlayer() instanceof AiPlayer) ) return;
		else {
			Lock lock = new ReentrantLock();
			lock.lock();
			
			/*
			 * ## =================== AI strategy ========================
			 * 1. draw cards until mana is not adequate
			 * 2. consume all attack chances as many as possible
			 * 3. if possible, randomly move.
			 */
		
			// Assignee: the deployment is implemented by @Yueyue Liu, @Yaqi Wang and @You Li, together with the helper methods.
			// ## 1. draw some cards regardless of card type
			if (((AiPlayer) this.player).ableToDeployCard()) {
				
				var cards = this.hand.getRandomCards(this.player.getMana()); // ## this.player.getMana();
				
				while (!cards.isEmpty()) {
					
					Collections.shuffle(cards);
					var card = cards.pop();
//					Card card = BasicObjectBuilders.loadCard(StaticConfFiles.c_pureblade_enforcer, 41, SpellCard.class);
//					((HandCard) card).setCardConfPath(StaticConfFiles.c_pureblade_enforcer);
//					((HandCard) card).setAbilityType(this.hand.getAbilityType(StaticConfFiles.c_pureblade_enforcer));
//					((HandCard) card).setPrevHandPosition(4);
					
					if (card instanceof SpellCard) {
						
						// ## scanning for targets
						log.info(String.format("AI spelling...\n%s\n", (HandCard) card));
						gameState.whoseTurn().setCardOnHold(card);
						var targets = ((SpellCard) card).spellShowTargetUnit(out, gameState);
						try {Thread.sleep(1200);} catch (Exception e) {e.printStackTrace();}
						targets.forEach(pos -> gameState.getCell(pos[0], pos[1]).displayWithMode(out, 0));
						
						// ## randomly pick one target if has
						if (!targets.isEmpty()) {
							
							Collections.shuffle(targets);
							int[] tmpPos = targets.pop();
							gameState.whoseTurn().setUnitLastClicked(gameState.getCell(tmpPos[0], tmpPos[1]).getSurfaceUnit());
							
							// ## deploy a spell card
							((SpellCard) card).spellAbilityTriggered(out, gameState);
							System.out.println("hand remains: " + this.hand.getHandSize());
						} else if ( targets.isEmpty() ) {
							
							// ## in some cases player can draw a card but cannot deploy it - [desperate situation - end the deployment phase]
							log.error("validate decay..");
							boolean allUnavailable = true;
							for (var nextCard : cards) {
								System.out.println(((HandCard) nextCard).getCardConfPath());
								if (!((HandCard) nextCard).getCardConfPath().equals(StaticConfFiles.c_entropic_decay))
									allUnavailable = false;
							}
							
							if (allUnavailable) {
								log.warn("ai doesn't have more cards to deploy");
								break;	// ## although card is available to mana, but no targets to deploy, and you can only use this card - desperation situation
							}
						}
					} else if (card instanceof UnitCard) {
						
						// ## scanning for targets
						log.info(String.format("AI uniting...\n%s\n", (HandCard) card));
						
						gameState.whoseTurn().setCardOnHold(card);
						var tiles = ((UnitCard) card).unitShowSummonTile(out, gameState);
						try {Thread.sleep(1200);} catch (Exception e) {e.printStackTrace();}
						
						// ## randomly deploy
						Collections.shuffle(tiles);
						int[] posToDrop = tiles.pop();
						gameState.whoseTurn().deployCardToCell(out, gameState, gameState.getCell(posToDrop[0], posToDrop[1]));
						System.out.println("hand remains: " + this.hand.getHandSize());
					}
					
					try { Thread.sleep(3600); } catch (Exception e) {e.printStackTrace();}
					gameState.whoseTurn().setUnitLastClicked(null);
					cards = this.hand.getRandomCards(this.player.getMana()); // ! replace with this.player.getMana
				}
						
				log.info("ai deployed some cards");
				((AiPlayer) this.player).cardDeployPerformed(out, gameState);
			}
			
			try {Thread.sleep(1200);} catch (Exception e) {e.printStackTrace();}
			
			// Assignee: the deployment is implemented by @Yingbo Ge, @Yaqi Wang and @Xinyu Tian, together with the helper methods.
			// ## 2. attack
			if (((AiPlayer) this.getPlayer()).ableToAttack()) {
				
				// ## get all my units and scan adjacent range of each of them and random attack a unit.
				var friendUnits = gameState.whoseTurn().scanUnitInBoard(gameState, false, false);
				while(!friendUnits.isEmpty()) {
					int[] attackerPos = friendUnits.pop();
					System.out.printf("next friend attack from tile[%d][%d]\n", attackerPos[0], attackerPos[1]);
					var attackerUnit = ((OperatableUnit) gameState.getCell(attackerPos[0], attackerPos[1]).getSurfaceUnit());
					
					// ## attacker show up
					gameState.getCell(attackerPos[0], attackerPos[1]).displayWithMode(out, 1);
					try { Thread.sleep(1200); } catch (Exception e) {e.printStackTrace();}
					gameState.getCell(attackerPos[0], attackerPos[1]).displayWithMode(out, 0);
					
					// show the attackee
					var thisAttackerTargets = attackerUnit.unitShowAttackRange(attackerPos[0], attackerPos[1], out, gameState);
					
					if (thisAttackerTargets.size() == 0 || thisAttackerTargets == null)
						continue;
					
					// ## pick any one to attack
					Collections.shuffle(thisAttackerTargets);
					int[] victimPos = thisAttackerTargets.pop();
					Cell victim = gameState.getCell(victimPos[0], victimPos[1]);
					if (!victim.tileHasUnit()) continue;
					
					// ## target display
					victim.displayWithMode(out, 2);
					try { Thread.sleep(1200); } catch (Exception e) {e.printStackTrace();}
					victim.displayWithMode(out, 0);
					
					// ## ai auto-attack
					gameState.whoseTurn().setUnitLastClicked(attackerUnit);
					victim.getAttackedStrategyAdvisor(out, gameState.getCell(attackerPos[0], attackerPos[1]), gameState);
					try { Thread.sleep(3600);; } catch (Exception e) {e.printStackTrace();}
					gameState.whoseTurn().setUnitLastClicked(null);
				}
				
				log.info("ai attacked some units");
				((AiPlayer) this.player).unitAttackPerformed();
			}

			try {Thread.sleep(1200);} catch (Exception e) {e.printStackTrace();}
			
			// Assignee: the deployment is implemented by @Yingbo Ge and @Xinyu Tian, together with the helper methods.
			// ## 3. move 
			if (((AiPlayer) this.player).ableToMove()) {
				
				var friendUnits = gameState.whoseTurn().scanUnitInBoard(gameState, false, false);
				while (!friendUnits.isEmpty()) {
					int[] tmpPos = friendUnits.pop();
					Unit unit = ((OperatableUnit) gameState.getCell(tmpPos[0], tmpPos[1]).getSurfaceUnit());
					
					// ## unit-to-move highlighted
					gameState.getCell(tmpPos[0], tmpPos[1]).displayWithMode(out, 1);
					try { Thread.sleep(1200); } catch (Exception e) {e.printStackTrace();}
					gameState.getCell(tmpPos[0], tmpPos[1]).displayWithMode(out, 0);
					
					if ( !(((OperatableUnit) unit).hasMoveChance()) ) continue;
					
					if ( ((OperatableUnit)unit).hasMoveChance() ) {
						var moveRange = ((OperatableUnit) unit).unitShowMoveRange(tmpPos[0], tmpPos[1], out, gameState);
						
						// ## if not provoked then the size should be above 0
						if (moveRange.size() > 0 && !moveRange.isEmpty()) {
							Collections.shuffle(moveRange);
							int[] nextPos = moveRange.pop();
							Cell destination = gameState.getCell(nextPos[0], nextPos[1]);
							
							// ## target test
							destination.displayWithMode(out, 1);
							try { Thread.sleep(1200); } catch (Exception e) {e.printStackTrace();}
							destination.displayWithMode(out, 0);
							
							// ## ai auto-move
							gameState.whoseTurn().setUnitLastClicked(unit);
							gameState.whoseTurn().moveUnitToCell(out, gameState, gameState.getCell(nextPos[0], nextPos[1]));
							gameState.whoseTurn().setUnitLastClicked(null);
						}
					}
					
					try {Thread.sleep(3600);} catch (Exception e) {e.printStackTrace();}
					gameState.whoseTurn().setUnitLastClicked(null);
				}
				
				log.info("ai moved some units");
				((AiPlayer) this.player).unitMovePerformed();
			}
			
			try {Thread.sleep(1200);} catch (Exception e) {e.printStackTrace();}
			lock.unlock();
			
			if (!((AiPlayer) player).ableToDeployCard() 
					&& !((AiPlayer) player).ableToAttack()
					&& !((AiPlayer) player).ableToMove()) {
				gameState.endWhoseverTurn();
			}
			return;
		}
	}
}

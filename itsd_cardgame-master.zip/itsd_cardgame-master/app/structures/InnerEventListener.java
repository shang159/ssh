package structures;

import akka.actor.ActorRef;
import structures.basic.Unit;

public interface InnerEventListener {

	/**events that may happens on the board*/
	public static enum InnerEventType {
		ON_SUMMON,
		UNIT_DEALTH,
		SPELL_CAST,
		AVATAR_DAMAGE;
	}
	
	public void innerEventProcessor(Unit unit, InnerEventType eventType, ActorRef out, GameState gameState);
}

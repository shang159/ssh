package structures;

public class Turn {

	private int remainingTime;
	
	public static int globalTurnIndex = 0;
	
	private final double HEARTBEAT_INTERVAL = 1.2;
	private final int TIME_LIMITS = 75; // ## setting countdown timer ->
										// = heartbeat * 75 = 1.2sec * 75 = 90sec/turn
	public Turn() {
		this.remainingTime = TIME_LIMITS;
		++globalTurnIndex;
	}

	private boolean overTime() {
		return remainingTime <= 0 ? true : false;
	}
	
	public boolean decreaseTime() {
		this.remainingTime -= 1;
		return overTime();
	}
	
	public double getRemainingSecs() {
		return this.remainingTime * HEARTBEAT_INTERVAL;
	}
}

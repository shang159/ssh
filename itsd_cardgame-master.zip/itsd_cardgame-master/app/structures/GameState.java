package structures;

import java.util.Arrays;
import java.util.LinkedList;

import com.fasterxml.jackson.databind.introspect.TypeResolutionContext.Basic;

import akka.actor.ActorRef;
import akka.actor.PoisonPill;
import commands.BasicCommands;
import play.api.Play;
import structures.basic.Deck;
import structures.basic.Player;
import structures.basic.Tile;
import structures.basic.Unit;
import structures.basic.Hand;
import structures.basic.HumanPlayer;
import utils.BasicObjectBuilders;
import utils.StaticConfFiles;
import structures.basic.AiPlayer;
import structures.basic.Cell;
/**
 * This class can be used to hold information about the on-going game.
 * Its created with the GameActor.
 * 
 * @author Dr. Richard McCreadie
 *
 */
public class GameState {
	
	public ActorRef out;
	private Cell[][] board;	// ## (0,0) -> (4,8)
	public GameElementSet human;
	public GameElementSet robot;
	
	private boolean player1Turn; // ## Player1Turn = !Player2Turn
	private static boolean EOG; 		// ## End of Game
	
	public static final int TOTAL_ROWS = 5;
	public static final int TOTAL_COLS = 9;
	
	@Deprecated
	public GameState() {
		;
	}
	
	public GameState(ActorRef aOut) {
		this.out = aOut;
	}
	
	public void init() {
		// ## globalTurn: 1, 2, 3, 4
		this.player1Turn = true; // ## human always start frist
		GameState.EOG = false;
		
		// ## initialize the board
		board = new Cell[TOTAL_ROWS][TOTAL_COLS];
		for (int j = 0; j < TOTAL_COLS; j++) {
			for (int i = 0; i < TOTAL_ROWS; i++) {
				board[i][j] = new Cell(i, j); // ## [3, 2]
			}
		}
		
		// ## draw clear tiles
		this.displayTiles(out, 0);	// ## put tile underneath unit

		// ## generating cards
		Deck[] tmp = (DeckGenerator.generateDecks(false));
		Deck deck1 = tmp[0];
		Deck deck2 = tmp[1];
		
		// Assignee: the drawing function is implemented by @Yingbo Ge and @You Li, together with the helper methods.
		// ## two players setup
		human = new GameElementSet(new HumanPlayer(), deck1, new Hand(), StaticConfFiles.humanAvatar);
		robot = new GameElementSet(new AiPlayer(), deck2, new Hand(), StaticConfFiles.aiAvatar);
		this.board[2][1].setupNewUnit(human.getAvatarUnit(), out, this);
		this.board[2][7].setupNewUnit(robot.getAvatarUnit(), out, this);
		BasicCommands.setPlayer1Health(out, getPlayer1());
		BasicCommands.setPlayer2Health(out, getPlayer2());

	}
	
	public boolean isPlayer1Turn() {
		return this.player1Turn;
	}
	
	public boolean isEOG() {
		return GameState.EOG;
	}
	
	public void endTheGame() {
		GameState.EOG = true;
		out.tell(PoisonPill.getInstance(), out);
		System.exit(0);
	}
	
	public GameElementSet whoseTurn() {
		return player1Turn ? this.human : this.robot;
	}
	
	public GameElementSet notWhoseTurn() {
		return player1Turn ? this.robot : this.human;
	}
	
	/**Return the Player1 (HumanPlayer.class) in this game*/
	public Player getPlayer1() {
		return this.human.getPlayer();
	}
	
	/**Return the Player2 (AiPlayer.class) in this game*/
	public Player getPlayer2() {
		return this.robot.getPlayer();
	}
	
	/**Directly operate a cell. Often used for checking Cell Status Code*/
	public Cell getCell(int row, int col) {
		
		// ## out of boundary check provided to code-user
		if (row < 0 || row > GameState.TOTAL_ROWS - 1 
				|| col < 0 || col > GameState.TOTAL_COLS - 1) {
			return null;
		} else {
			return this.board[row][col];
		}
	}
	
	/**Display the entire board with clear tiles*/
	private void displayTiles(ActorRef out, int mode) {	// ## mode: [0]=clear, [1]=white, [2]=red
		if (this.board.length > 0) {
			for (int i = 0; i < TOTAL_ROWS; i++) {
				for (int j = 0; j < TOTAL_COLS; j++) {
					board[i][j].displayWithMode(out, mode);
//					System.out.println(board[i][j].getCellStatus());	// ## status code test
				}
			}
		}
	}
	// Assignee: the mana drain is implemented by @Xinyu Wang, together with the helper methods.
	public void endWhoseverTurn() {
		this.whoseTurn().clearRangeActivated(this.out, this); // ## clear all remaining bug shadows
		
		// ## find whose the turn is 
		if (player1Turn) {
			this.human.endTurn();
			
			// ## draw new card
			this.human.supplementSingleCard(this.out);
			
			// ## flush mana
			this.getPlayer1().setMana(0);
			BasicCommands.setPlayer1Mana(this.out, this.getPlayer1());
			
			BasicCommands.addPlayer1Notification(this.out, "turn is over", 6);
			
			// ## flip the states to false
			player1Turn = false;
		} else {
			
			this.robot.endTurn();
			this.robot.supplementSingleCard(this.out);
			this.getPlayer2().setMana(0);
			BasicCommands.setPlayer2Mana(this.out, this.getPlayer2());
			player1Turn = true;
		}
	}
}

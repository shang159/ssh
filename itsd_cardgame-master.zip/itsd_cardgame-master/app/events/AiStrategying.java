package events;

import akka.actor.ActorRef;
import structures.GameState;
import structures.basic.AiPlayer;

/**AI strategy is run by an independent thread*/
public class AiStrategying implements Runnable {

	private ActorRef out;
	private GameState gameState;
	
	public AiStrategying(ActorRef out, GameState gameState) {
		this.out = out;
		this.gameState = gameState;
	}

	@Override
	public void run() {
		gameState.robot.strategyApplied(out, gameState); // ## strategy
	}

}

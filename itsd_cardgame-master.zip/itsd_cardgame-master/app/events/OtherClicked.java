package events;

import com.fasterxml.jackson.databind.JsonNode;

import akka.actor.ActorRef;
import commands.BasicCommands;
import structures.GameState;
import structures.basic.AvatarUnit;
import structures.basic.Unit;
import utils.BasicObjectBuilders;

/**
 * Indicates that the user has clicked an object on the game canvas, in this case
 * somewhere that is not on a card tile or the end-turn button.
 * 
 * { 
 *   messageType = “otherClicked”
 * }
 * 
 * @author Dr. Richard McCreadie
 *
 */
public class OtherClicked implements EventProcessor{

	@Override
	public void processEvent(ActorRef out, GameState gameState, JsonNode message) {
		// ## temporially used for testing functionality
		
		// ## test01 : cell status code test 
//		gameState.board[2][0].setCellStatus("010"); // tested
//		System.out.println(gameState.board[2][0].getCellStatus()); // tested
		
		// ## test02 : deleteUnit test
//		gameState.board[2][1].deleteUnitOnIt(out);
//		gameState.board[2][7].deleteUnitOnIt(out);
//		Player failed problem fixed by correct GES logic
	}

}



package events;

import akka.actor.ActorRef;
import structures.GameState;
import structures.basic.Cell;
import structures.basic.Unit;
/**the goal of this class is to solve human moving unit thread-block problem.
 * the class will solve the problem by assign another thread dedicated to human moving*/
public class HumanUnitOperating implements Runnable {

	ActorRef out;
	GameState gameState;
	Cell target;
	WithMovingOperation movingType;
	
	enum WithMovingOperation {
		MOVE_TO,
		ATTACK_TO;
	}
	
	public HumanUnitOperating(ActorRef aOut, GameState aGameState, Cell aTarget, WithMovingOperation aMovingType) {
		// TODO Auto-generated constructor stub
		this.out = aOut;
		this.gameState = aGameState;
		this.target = aTarget;
		this.movingType = aMovingType;
	}

	@Override
	/**assign thread for operation involving 'move'*/
	public void run() {
		// TODO Auto-generated method stub
		if (movingType.equals(WithMovingOperation.MOVE_TO)) {
			
			// ## move
			gameState.whoseTurn().moveUnitToCell(this.out, this.gameState, this.target);
			
			// ## reset unit-click state
			gameState.whoseTurn().setUnitLastClicked(null);
		} else if (movingType.equals(WithMovingOperation.ATTACK_TO)) {
			
			// ## attack & auto counter-attack
			Unit unitLastClicked = gameState.whoseTurn().getUnitLastClicked();
			target.getAttackedStrategyAdvisor(out, gameState.getCell(unitLastClicked.getRow(), unitLastClicked.getCol()), gameState);
			
			// ## clean up
			gameState.getCell(unitLastClicked.getRow(), unitLastClicked.getCol()).unitTriggerUndo();
			System.out.println("==> attacker status: " + gameState.getCell(unitLastClicked.getRow(), unitLastClicked.getCol()).getCellStatus());
			gameState.human.setUnitLastClicked(null);
		}
		
	}

}

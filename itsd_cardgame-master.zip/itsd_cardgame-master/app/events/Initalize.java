package events;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ObjectNode;

import akka.actor.ActorRef;
import commands.BasicCommands;
import demo.CommandDemo;
import play.libs.Json;
import structures.DeckGenerator;
import structures.GameState;
import structures.basic.Card;
import structures.basic.Deck;
import structures.basic.HandCard;
import structures.basic.OperatableUnit;
import structures.basic.Player;
import structures.basic.Unit;
import structures.basic.UnitCard;
import utils.BasicObjectBuilders;
import utils.StaticConfFiles;

import java.util.Arrays;
import java.util.LinkedList;
import java.util.Objects;

// ## appended using logging rather than out.print
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Indicates that both the core game loop in the browser is starting, meaning
 * that it is ready to recieve commands from the back-end.
 * 
 * { 
 *   messageType = “initalize”
 * }
 * 
 * @author Dr. Richard McCreadie
 *
 */
public class Initalize implements EventProcessor{

	@Override
	public void processEvent(ActorRef out, GameState gameState, JsonNode message) {
		
//		CommandDemo.executeDemo(out); // this executes the command demo, comment out this when implementing your solution
		
		// ## appended
		gameState.init(); // ## tested
		
		// ## each player draw 3 cards
		gameState.human.supplementSingleCard(out);
		gameState.human.supplementSingleCard(out);
		gameState.human.supplementSingleCard(out);
//		gameState.human.supplementSingleCard(out);
//		gameState.human.supplementSingleCard(out);
		
		gameState.robot.supplementSingleCard(out);
		gameState.robot.supplementSingleCard(out);
		gameState.robot.supplementSingleCard(out);
//		gameState.robot.supplementSingleCard(out);
//		gameState.robot.supplementSingleCard(out);
		
//		BasicCommands.addPlayer2Notification(out, "My Greetings", 8);
		
		// ## create two fake enemy units
//		Card enemyCard_1 = BasicObjectBuilders.loadCard(StaticConfFiles.c_pyromancer, 1, UnitCard.class);
//		((HandCard) enemyCard_1).setCardConfPath(StaticConfFiles.c_pyromancer);
//		OperatableUnit enemyUnit_1 = (OperatableUnit) BasicObjectBuilders.loadUnit(StaticConfFiles.u_pyromancer, 4, OperatableUnit.class);
//		enemyUnit_1.setPlayer(gameState.getPlayer2());
//		enemyUnit_1.setInnerCard(enemyCard_1);
//		gameState.getCell(0, 5).setupUnit(enemyUnit_1, out, gameState);
//		
//		Card enemyCard_2 = BasicObjectBuilders.loadCard(StaticConfFiles.c_bloodshard_golem, 2, UnitCard.class);
//		((HandCard) enemyCard_2).setCardConfPath(StaticConfFiles.c_bloodshard_golem);
//		OperatableUnit enemyUnit_2 = (OperatableUnit) BasicObjectBuilders.loadUnit(StaticConfFiles.u_bloodshard_golem, 5, OperatableUnit.class);
//		enemyUnit_2.setPlayer(gameState.getPlayer2());
//		enemyUnit_2.setInnerCard(enemyCard_2);
//		gameState.getCell(3, 3).setupUnit(enemyUnit_2, out, gameState);
//		
//		// ## create one fake unit of mine !!!! bug of unit_id
//		Card myCard_2 = BasicObjectBuilders.loadCard(StaticConfFiles.c_hailstone_golem, 3, UnitCard.class);
//		((HandCard) myCard_2).setCardConfPath(StaticConfFiles.c_hailstone_golem);
//		OperatableUnit myUnit_2 = (OperatableUnit) BasicObjectBuilders.loadUnit(StaticConfFiles.u_hailstone_golem, 6, OperatableUnit.class);
//		myUnit_2.setPlayer(gameState.getPlayer1());
//		myUnit_2.setInnerCard(myCard_2);
//		gameState.getCell(2, 6).setupUnit(myUnit_2, out, gameState); // ## ! TEST: change your unit position here
		
	}
}



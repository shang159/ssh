package events;

import com.fasterxml.jackson.databind.JsonNode;

import akka.actor.ActorRef;
import commands.BasicCommands;
import play.utils.Threads;
import structures.GameState;
import structures.basic.AiPlayer;

/**
 * In the user’s browser, the game is running in an infinite loop, where there is around a 1 second delay 
 * between each loop. Its during each loop that the UI acts on the commands that have been sent to it. A 
 * heartbeat event is fired at the end of each loop iteration. As with all events this is received by the Game 
 * Actor, which you can use to trigger game logic.
 * 
 * { 
 *   String messageType = “heartbeat”
 * }
 * 
 * @author Dr. Richard McCreadie
 *
 */
public class Heartbeat implements EventProcessor{

	private static Thread aiThread = null;
	@Override
	public void processEvent(ActorRef out, GameState gameState, JsonNode message) {
		
		if (gameState.isEOG()) return; // ## End Of Game
		
		// ## each player take turn based on Tik-Tok
		if (gameState.isPlayer1Turn() && !gameState.isEOG()) { 		// ## if it should be my turn
			
			// ## check whether the human turn has started
			if (gameState.human.turnIsStarted()) {
				
				// ## turn has already started, count-down 90 secs
				boolean overTime = gameState.human.receiveHeartBeat();
				if (overTime) gameState.endWhoseverTurn();
			} else if (!gameState.human.turnIsStarted()) {	

				// ## terminate ai thread
				if (aiThread != null) {
					try {aiThread.join();} catch (Exception e) {e.printStackTrace();}
					aiThread = null;
				}
				
				// ## if my turn hasn't started, then start it.
				gameState.human.takeMyTurn(gameState);
				BasicCommands.addPlayer1Notification(out, "I have 90 seconds to go", 7);
				BasicCommands.setPlayer1Mana(out, gameState.getPlayer1());
				gameState.human.receiveHeartBeat();
			} 
		} else if (!gameState.isPlayer1Turn() && !gameState.isEOG()){
			
			if (gameState.robot.turnIsStarted()) {	// ## !thread problem
				
				boolean overTime = gameState.robot.receiveHeartBeat();
				if (overTime) gameState.endWhoseverTurn();
				
				if (aiThread == null) {
					aiThread = new Thread(new AiStrategying(out, gameState));
					aiThread.start();
				}
			} else if (!gameState.robot.turnIsStarted()){
				
				gameState.robot.takeMyTurn(gameState);
				BasicCommands.setPlayer2Mana(out, gameState.getPlayer2());
				gameState.robot.receiveHeartBeat();
			}
		}
		// End of HB
	}
}

package events;

import com.fasterxml.jackson.databind.JsonNode;

import akka.actor.ActorRef;
import structures.GameState;
import akka.actor.PoisonPill;
import play.api.Play;
/**
 * Indicates that the user has clicked an object on the game canvas, in this case
 * the end-turn button.
 * 
 * { 
 *   messageType = “endTurnClicked”
 * }
 * 
 * @author Dr. Richard McCreadie
 *
 */
public class EndTurnClicked implements EventProcessor{

	
	@Override
	// Assignee: the end-turn is implemented by @Yingbo Ge and @You Li, together with the helper methods.
	public void processEvent(ActorRef out, GameState gameState, JsonNode message) {
		if (gameState.isEOG()) return; // ## End Of Game
		
		if (gameState.isPlayer1Turn() && gameState.human.turnIsStarted()) {
			gameState.endWhoseverTurn();		
		} else {
			System.out.println("Not your turn or haven't started");
		}

	}

}

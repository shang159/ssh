package events;


import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.introspect.TypeResolutionContext.Basic;

import akka.actor.ActorRef;
import commands.BasicCommands;
import structures.GameState;
import structures.basic.AiPlayer;
import structures.basic.Card;
import structures.basic.HandCard;
import structures.basic.HandCard.AbilityType;
import structures.basic.OperatableUnit;
import structures.basic.SpellCard;
import structures.basic.Unit;
import structures.basic.UnitCard;
import utils.BasicObjectBuilders;
import utils.StaticConfFiles;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
/**
 * Indicates that the user has clicked an object on the game canvas, in this case a card.
 * The event returns the position in the player's hand the card resides within.
 * 
 * { 
 *   messageType = “cardClicked”
 *   position = <hand index position [1-6]>
 * }
 * 
 * @author Dr. Richard McCreadie
 *
 */
public class CardClicked implements EventProcessor{

	@Override
	public void processEvent(ActorRef out, GameState gameState, JsonNode message) {
		
		int handPosition = message.get("position").asInt();
		
		if (gameState.isEOG()) return; // ## End Of Game
		
		if (gameState.whoseTurn().getPlayer().getClass().equals(gameState.getPlayer1().getClass())) {
			processEventWithMyCard(out, gameState, handPosition);
		} else {
			System.out.println("/--> Not your turn");
		}
	}
	
	public void processEventWithMyCard(ActorRef out, GameState gameState, int handPosition) {
		
		// ## validate whether there remains unit activated, if so -> invalidate this card click
		if (gameState.human.getUnitLastClicked() != null) {
			BasicCommands.addPlayer1Notification(out, "You've activated a unit. Please de-activate to deploy cards", 10);
			return;
		}
		
		if (gameState.human.getCardOnHold() != null) {
			
			// ## undo card's range display if already hold one
			gameState.human.clearRangeActivated(out, gameState);
			BasicCommands.drawCard(out, gameState.human.getCardOnHold(), handPosition, 0);
			gameState.human.setCardOnHold(null);
		} else if (gameState.human.getCardOnHold() == null ) {
			
			// ## get the card clicked
			Card cardEntity = gameState.human.getCardFromHand(handPosition);	 // ## replace this with test sentence
			
//			Card cardEntity = BasicObjectBuilders.loadCard(StaticConfFiles.c_sundrop_elixir, 42, SpellCard.class);
//			((HandCard) cardEntity).setCardConfPath(StaticConfFiles.c_sundrop_elixir);
//			((HandCard) cardEntity).setAbilityType(AbilityType.BUILT_IN);
//			((HandCard) cardEntity).setPrevHandPosition(handPosition);
			
			System.out.println("Card Clicked on:\n" + cardEntity);
			gameState.human.setCardOnHold(cardEntity);
			BasicCommands.drawCard(out, gameState.human.getCardOnHold(), handPosition, 1);
			
			// ## mana check
			if ( ((HandCard) cardEntity).getManacost() > gameState.getPlayer1().getMana() ) {
				
				BasicCommands.addPlayer1Notification(out, "You don't have enough mana to play this card", 6);
			} else {
				
				/// add the sentences below
				if ( ((HandCard) cardEntity).isUnitCard() ) {
					((UnitCard) gameState.human.getCardOnHold()).unitShowSummonTile(out, gameState);	// ## unit cards show summon range
				} else {
					((SpellCard) gameState.human.getCardOnHold()).spellShowTargetUnit(out, gameState);	// ## spell cards show (de)buff range
				}
			}
		} 
	}
}


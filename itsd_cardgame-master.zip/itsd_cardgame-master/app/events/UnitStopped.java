package events;


import com.fasterxml.jackson.databind.JsonNode;

import akka.actor.ActorRef;
import structures.GameState;
import structures.basic.OperatableUnit;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
/**
 * Indicates that a unit instance has stopped moving. 
 * The event reports the unique id of the unit.
 * 
 * { 
 *   messageType = “unitStopped”
 *   id = <unit id>
 * }
 * 
 * @author Dr. Richard McCreadie
 *
 */
public class UnitStopped implements EventProcessor{

	final Logger log = LoggerFactory.getLogger(this.getClass());
	@Override
	public void processEvent(ActorRef out, GameState gameState, JsonNode message) {
		
		int unitid = message.get("id").asInt();
		
		// ## appended helper info
		int tilex = message.get("tilex").asInt();
		int tiley = message.get("tiley").asInt();
		int row = tiley;
		int col = tilex;

		// ## thread wait - check whether the unit is correctly setup on the new tile
		while ( !(gameState.getCell(row, col).tileHasUnit()) ) {
			try { Thread.sleep(100); } catch (Exception e) {e.printStackTrace();}
			System.out.println("Unit hasn't prepared yet (msg. from " + this.getClass() + ")");
		}
		
		// ## move conducted
		((OperatableUnit) gameState.getCell(row, col).getSurfaceUnit()).movePerformed(); // opportunity - 1
		int restStep = ((OperatableUnit) gameState.getCell(row, col).getSurfaceUnit()).getRemainedMoveChance();
		System.out.printf("==> Unit at Cell[%d][%d] remains %d chance(s) to conduct movement. msg from %s\n", row, col, restStep, this.getClass());
	}

}

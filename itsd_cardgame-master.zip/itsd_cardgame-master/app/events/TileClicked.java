package events;

import java.util.LinkedList;

import com.fasterxml.jackson.databind.JsonNode;

import akka.actor.ActorRef;
import commands.BasicCommands;
import events.HumanUnitOperating.WithMovingOperation;
import structures.GameState;
import structures.basic.AiPlayer;
import structures.basic.Card;
import structures.basic.Cell;
import structures.basic.OperatableUnit;
import structures.basic.SpellCard;
import structures.basic.Tile;
import structures.basic.Unit;
import structures.basic.UnitAnimationType;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Indicates that the user has clicked an object on the game canvas, in this case a tile.
 * The event returns the x (horizontal) and y (vertical) indices of the tile that was
 * clicked. Tile indices start at 1.
 * 
 * { 
 *   messageType = “tileClicked”
 *   tilex = <x index of the tile>
 *   tiley = <y index of the tile>
 * }
 * 
 * @author Dr. Richard McCreadie
 *
 */
public class TileClicked implements EventProcessor {

	Logger log = LoggerFactory.getLogger(this.getClass());
	
	@Override
	public void processEvent(ActorRef out, GameState gameState, JsonNode message) {

		int tilex = message.get("tilex").asInt();
		int tiley = message.get("tiley").asInt();
		
		if (gameState.isEOG()) return; // ## End Of Game
		
		int row = tiley;
		int col = tilex;
		
		// <FILTER 1> - check whose turn: Tik Turn in "tik-tok"
		if (gameState.isPlayer1Turn()) {
			
			// <FILTER 2> - check unit on it: Clicked on a unit
			if (gameState.getCell(row, col).tileHasUnit()) {
				
				// ## multi-thread synchronizor
				
				// <FILTER 3>  - check unit ownership: My unit
				if (gameState.whoseTurn().getPlayer().equals(gameState.getCell(row, col).whoseCell())) {
					System.out.printf("==> this is your turn, valid click on your unit on tile[%d][%d]\n", row, col);
					processEventWithMyUnit(out, gameState, row, col);
				} else {
					System.out.printf("==> this is your turn, valid click on ENEMY unit on tile[%d][%d]\n", row, col);
					processEventWithEnemyUnit(out, gameState, row, col);
				}// </FILTER 3 Ends> : Not my unit
			} else {
				
				processEventWithoutUnit(out, gameState, row, col);
			}// </FILTER 2 Ends> : Clicked on a tile
		} else {
			
			System.out.println("Not your turn");
		}// </FILTER 1 Ends>			
	}
	
	/*
	 * ==========================Tile Click and Activation Complete Logic Table==========================
	 * 
	 * 	case	unitLastClicked		unitThisClicked		Expected Operation & Explanation
	 * 
	 * 	1		null				null				[summon / INVALID] - further examination in sub-cases
	 * 	2		null				my unit				[highlight / buff / INVALID] - further examination in sub-cases
	 * 	3		my unit				null				[move] - last time activate my unit, this time click on a tile
	 * 	4		my unit				my unit				[de-highlight / INVALID] - last time activate my unit, this time again clicked on my unit
	 * 	5		my unit				enemy unit			[attack] u2u - last time activate my unit, this time click on an enemy unit.
	 * 	6 		null				enemy unit			[debuff / INVALID] c2u/ranged - last time should activate a card, this time click on an enemy unit.
	 * 
	 * ------------------------------sub-cases of case [2]---------------------------------------
	 * 
	 * case		unitLastClicked		unitThisClicked		CardActivated	Meaning
	 * 
	 * 2.a.1		null				my unit				NULL		[range highlight] - first time clicked on my unit
	 * 2.a.2		null				enemy unit			NULL		[INVALID] - first time clicked on enemy unit
	 * 2.b.1		null				my unit				YES[buff]	[buff] - buff spell, card2unit
	 * 				null				my unit				YES[Other]	[INVALID] - can only deploy a spell buff my unit in this situation
	 * 
	 * ----------------------------sub-cases of case [2.a.1]-------------------------------------
	 * 
	 * 	case	unitLastClicked		unitThisClicked		Opportunity				Expected Operation
	 * 
	 * 	A			null			my unit				MOVE[y] / ATTACK[y]		white & red highlighted tiles
	 * 	B			null			my unit				MOVE[N] / ATTACK[y]		red highlighted tile if there exists
	 * 	C			null			my unit				MOVE[y] / ATTACK[N]		white highlighted tile if there exists
	 * 	D			null			my unit				MOVE[N] / ATTACK[N]		none
	 * 
	 * ! NOTE: case B, C, D may fall into "Desperation Situation" that the unit can attack BUT have no targets or can move BUT have no tiles to move.
	 * ! in the so-called "Desperation Situation", Cell Status Code (CSC) will be hard-reset since nothing can be done by player.
	 * 
	 * ------------------------------sub-cases of case [4]---------------------------------------
	 * 
	 * 	case	unitLastClicked		unitThisClicked		Expected Operation & Explanation
	 * 	
	 * 	4.a		my unit				my unit(the same)	[de-highlight] - last time activate my unit, this time the same unit will undo range display
	 * 	4.b		my unit				my unit(different)	[INVALID] - should click on the same unit to undo the highlight
	 * 
	 * ========================Events Processor Mapper of Cases to deal with===================
	 * 
	 * processEventWithoutUnit()	-> Case [1] and Case[3]
	 * processEventWithMyUnit()		-> Case [2] and Case[4], including their sub-cases 2.a.1, 2.b.1; A, B, C, D; 4.a, 4.b;
	 * processEventWithEnemyUnit()	-> Case [5] and Case[6], including their sub-cases 5.a ~ 5.d; 6.a, 6.b;
	 * 
	 */
	
	/**The method fully implements Case [2] and Case [4], 
	 * and examines all their sub-cases including 2.a.1 ~ 2.b.1 and A, B, C, D and 4.a & 4.b
	 * The method is associated with operations of "Range Display & Undo" and "Spell Buff"
	 * */
	public void processEventWithMyUnit(ActorRef out, GameState gameState, int row, int col) {
		
		Cell cellClicked = gameState.getCell(row, col);
		Unit unitThisClicked = cellClicked.getSurfaceUnit();
		Unit unitLastClicked = gameState.human.getUnitLastClicked();
		
		LinkedList<int[]> moveRange = new LinkedList<>(); 
		LinkedList<int[]> attackRange = new LinkedList<>(); 
		
		if (unitThisClicked != null && unitLastClicked == null && gameState.human.getCardOnHold() == null) {

			// Assignee: the board highlighting is implemented by @Yueyue Liu, together with the helper methods.
			// Assignee: the attack highlighting and clear are implemented by @Yaqi Wang, together with the helper methods.
			// ## case 2.a.1  highlight
			gameState.human.setUnitLastClicked(unitThisClicked);
				
			if (!cellClicked.unitIsTriggered()) {
				// ## case A, B, C, D
				if ( ((OperatableUnit) unitThisClicked).hasMoveChance() )
					moveRange = ((OperatableUnit) unitThisClicked).unitShowMoveRange(row, col, out, gameState);
				if ( ((OperatableUnit) unitThisClicked).hasAttackChance() )
					attackRange = ((OperatableUnit) unitThisClicked).unitShowAttackRange(row, col, out, gameState);
				try {Thread.sleep(240);} catch (InterruptedException e) {e.printStackTrace();}
			}
			cellClicked.unitTriggerPerformed();
			
			/*
			 * +++++++++++"Desperate Situation" - hard-reset all cases except Case A+++++++++++++
			 * 
			 *  case B - moved so can't display move range, but can attack
			 *  -> b.1: can attack but no targets in the range, nothing displayed -> set to default.
			 *  
			 *  case C -  attacked so can't display attack range, but can move
			 *  -> c.1: can move but no where to locate(surrounded in the corner by 3 enemies) -> set to default.
			 *  
			 *  case D - nothing can be done by the player
			 */
			if ( 	( ((OperatableUnit) unitThisClicked).hasAttackChance() && attackRange.size() > 0 )
					|| 
					( ((OperatableUnit) unitThisClicked).hasMoveChance() && moveRange.size() > 0) ) {
				;
			} else {
				gameState.human.setUnitLastClicked(null);
				log.info("[auto reset - desperate situation] status code has just been reseted");
			}
			
		} else if (unitThisClicked != null && unitLastClicked == null && gameState.human.getCardOnHold() != null) {
			
			// ## case 2.b.1 - Spell Buff (Sundrop & Y'Kir)
			// ## validate the targets
			if ( !cellClicked.unitIsAvailableForBuff() ) {
				BasicCommands.addPlayer1Notification(out, "Cannot target that unit", 3);
				return;
			}
			log.info(String.format("[buff spell] %s confirmed...", gameState.human.getCardOnHold().getCardname()));
			
			// ## record this click on unit, then -> spell deployed
			gameState.human.setUnitLastClicked(unitThisClicked);
			Card spellToBeDeployed = gameState.human.getCardOnHold();
			((SpellCard) spellToBeDeployed).spellAbilityTriggered(out, gameState);
			
			try {Thread.sleep(2400);} catch (Exception e) {e.printStackTrace();}
			
		} else if (unitThisClicked != null && unitLastClicked != null) {
			
			// ## case 4.a & 4.b de-highlight - second time clicked on my unit
			if (!unitThisClicked.equals(gameState.human.getUnitLastClicked())) {
				BasicCommands.addPlayer1Notification(out, "You must re-click the same unit to undo highlight", 10);
				return;
			}

			log.info(String.format("[de-highlight] second time clicked on my unit"));
			if (unitThisClicked.equals(gameState.human.getUnitLastClicked())) {
				
				// ## undo highlight
				gameState.human.clearRangeActivated(out, gameState);
				cellClicked.unitTriggerUndo();
				gameState.human.setUnitLastClicked(null);
			} 
		}
	}
	
	/*
	 * 	case	unitLastClicked		unitThisClicked		CardActivated	Expected Operation & Explanation
	 * 
	 * 	1.a		null				null				NULL			[INVALID]
	 * 	1.b		null				null				YES[UnitCard]	[summon] - click a tile without unit, BUT with a unit card
	 * 	3		my unit				null								[move] - last time activate my unit, this time click on a tile
	 */
	/**The method fully implements case [1] and case [3], and all their sub-cases.*/
	public void processEventWithoutUnit(ActorRef out, GameState gameState, int row, int col) {
		
		Cell cellClicked = gameState.getCell(row, col);
		Unit unitThisClicked = cellClicked.getSurfaceUnit();
		Unit unitLastClicked = gameState.human.getUnitLastClicked();
		
		if (unitThisClicked == null && unitLastClicked == null && gameState.human.getCardOnHold() != null){
			
			// ## case 1.b summon a unit - first time clicked on an empty tile with a card on hold
			// ## validate the targeted tile
			if (!cellClicked.tileIsAvailableForMoveOrSummon()) {
				BasicCommands.addPlayer1Notification(out, "Cannot deploy to there", 6);
				return;
			}
			
			if (cellClicked.tileIsAvailableForMoveOrSummon())
				gameState.human.deployCardToCell(out, gameState, cellClicked); 
			
		} else  if (unitThisClicked == null && unitLastClicked != null) {
			
			// ## case 3  - move
			// ## validate the targeted tile
			if ( ! cellClicked.tileIsAvailableForMoveOrSummon()) {
				BasicCommands.addPlayer1Notification(out, "Cannot move to there", 6);
				return;
			} 
			
			if(cellClicked.tileIsAvailableForMoveOrSummon()) {
				
				log.info(String.format("[Second Clicked - move] on tile confirmed, completing rest operations..."));
				
				// ## move
				Thread t_moveTo = new Thread(new HumanUnitOperating(out, gameState, cellClicked, WithMovingOperation.MOVE_TO), "moveThread");
				t_moveTo.start();
			}
		}
	}
	
	/*
	 *	case	unitLastClicked		unitThisClicked		Expected Operation & Explanation	
	 *
	 *	5		my unit				enemy unit			[attack] - unit2unit attack, last time activate my unit, this time click on an enemy unit.
	 *	6 		null				enemy unit			[debuff / INVALID] c2u - last time should activate a card, this time click on an enemy unit. 
	 *
	 * =====================================Attack logic==============================================
	 * 
	 * 	case	unitLastClicked		unitThisClicked			Opportunity				Meaning
	 * 	
	 * 	5.a		my unit				enemy unit				attack[y] / move[y]		(attack) u2u - my unit attack enemy unit but cannot move after attack
	 * 	5.b		my unit				enemy unit				attack[y] / move[N]		(attack) u2u - my unit attack enemy unit
	 * 	5.c		my unit				enemy unit				attack[N] / move[y]		(my unit out of chances to attack)
	 * 	5.d		my unit				enemy unit				attack[N] / mode[N]		(my unit out of chances to attack)
	 * 
	 * 	case	unitLastClicked		unitThisClicked			CardOnHold				Meaning
	 * 
	 * 	6.a		null				enemy unit				YES[debuff]				[debuff] c2u / ranged- debuff spell, card2unit
	 * 	6.b		null				enemy unit				YES[Other]				[INVALID] - can only deploy a spell debuff enemy unit in this situation
	 * 
	 * ===============================Detailed Attacking Outcomes====================================
	 * 	
	 * 	case		Outcome					Expected Operation
	 * 	
	 * 	5.a.1		my unit died		->	reset unitLastClicked, clean my unit on board
	 * 	5.a.2		counter unit died	->	clean counter unit on board
	 * 	5.a.3		neither died		->	my unit cannot move
	 * 	5.b			all the same with 5.a series
	 * 
	 */	
	
	/**The method implements case [5] and case[6] and all their sub-cases*/
	public void processEventWithEnemyUnit(ActorRef out, GameState gameState, int row, int col) {
		
		Cell cellClicked = gameState.getCell(row, col);
		Unit unitThisClicked = cellClicked.getSurfaceUnit();			// ## "unit this clicked" won't be null
		Unit unitLastClicked = gameState.human.getUnitLastClicked();
		
		// ## validate the click
		if (unitLastClicked == null && gameState.human.getCardOnHold() == null) {
			BasicCommands.addPlayer1Notification(out, "That's an enemy unit", 6);
			return;
		}
		
		if (unitLastClicked != null) {
			
			// Assignee: the attack is implemented by @Yueyue Liu and @Yaqi Wang, together with the helper methods.
			// ## case 5. a & 5.b - adjacent attack, ranged attack and move-then-attack
			// ## validate targets
			if ( !(cellClicked.unitIsAvailableForAttack()) || !((OperatableUnit) unitLastClicked).hasAttackChance() ) {
				BasicCommands.addPlayer1Notification(out, "Cannot attack that unit!", 6);
				return;
			}
			
			if ( cellClicked.unitIsAvailableForAttack() && ((OperatableUnit) unitLastClicked).hasAttackChance() ) {
				
				// ## final decision, complete the rest attacking process
				log.info("[attack] second time clicked on the enemy tile confirmed...");

				// -> replacement: attack & counter-attack
				Thread t_attackTo = new Thread(new HumanUnitOperating(out, gameState, cellClicked, WithMovingOperation.ATTACK_TO), "attackThread");
				t_attackTo.start();
			}
		} else if (unitLastClicked == null && gameState.human.getCardOnHold() != null) {
			
			// ## case 6. a - spell attack (truestrike & entropic decay)
			// ## validate the targets
			if ( !cellClicked.unitIsAvailableForAttack() ) {
				BasicCommands.addPlayer1Notification(out, "Cannot target that unit for now", 6);
				return;
			}
			log.info(String.format("[Spell attack] %s confirmed", gameState.human.getCardOnHold().getCardname()));
			
			// ## record this click on unit and deploy the spell
			gameState.human.setUnitLastClicked(unitThisClicked);
			Card cardEntity = gameState.human.getCardOnHold();
			((SpellCard) cardEntity).spellAbilityTriggered(out, gameState); // ## depending on the unitLastClicked to function
			try {Thread.sleep(2400);} catch (Exception e) {e.printStackTrace();}
		}
	}

}

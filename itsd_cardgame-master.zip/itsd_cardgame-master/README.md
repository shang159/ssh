[[_TOC_]]

# non-UofG account email mapping table
| Student | UofG acount email (gitlab-git) | non-UofG account email /or (local-git)|
| ------- | ------ | ------ |
| You Li | 2600058l@student.gla.ac.uk | veev99@163.com |
| Yingbo Ge | 2529143g@student.gla.ac.uk | gybsapphire@gmail.com |
| Yueyue Liu | 2515474l@student.gla.ac.uk | 2515474L@student.gla.ac.uk |
| Yaqi Wang | 2559212w@student.gla.ac.uk | 2559212W@student.gla.ac.uk |
| Xinyu Tian | 2531637t@student.gla.ac.uk | (none) |

# Team Project Retrospective (part of Workload)

(***Here is a brief Team Project Retrospective, which records parts of workload. For the entire full workload, please check the beginning of the sprint reports and the source code.***)

The team consisted of five members – Yingbo Ge, Xinyu Tian, Yueyue Liu, Yaqi Wang and You Li. All team members successfully deployed git, connected to gitlab, and setup their developing environments. Gitlab features are largely explored, for example, we use list/issues to record bugs and setup milestones, and we use wiki to write documentations. In the CardGame project wiki, you can review our class UML diagram, system design doc and test cases doc. Microsoft Teams was used as the daily scrum communication platform. The team used agile project management and divided the entire project into 6 sprints. 

Before starting the project, all team members did some preparations including materials and tutorials collection. We also analysed the project structure. After that, our team started programming. To summary this stage, the Play framework is explored, and the required front-end knowledge is obtained through this process. 

Yingbo Ge is the main developer, who is responsible for the overall developing schedule, technical support for members, and completed those hard-to-implemented story cards, as well as designing system architecture, base layer and refactor. Xinyu Tian completed story cards including moving, attacking, and some special unit abilities, and he is also responsible for summarising and submitting bugs as listed in the Gitlab. He also contributed to the AI logic and conducted testing. Yueyue Liu and Yaqi Wang completed story cards including overdraw, move ranging, attacking, AI logic design and implementation, and are also responsible for the modular testing. You Li completed story cards including starting health, mana gain, unit death and tested the code. All team members did an integrated test. 

Sprint reports are contributed mostly by Yueyue Liu and Yaqi Wang. Yaqi was responsible for preparing the initial structure and contents of each sprint for the draft report. At the same time, Yueyue made some reasonable changes to the structure and content of each sprint for the final report. 

Although members have some or do not have any previous experience on collaborating on such a giant team project, members are willing to get involved in the project and tried their best to write code. We respect members’ different backgrounds and understand that it is unlikely to apply a one-size-fit-all rules of developing. Members sometimes submitted raw code, which may not function perfectly, the code eventually fits well in the system with the support of members who know how to refine. 

To keep the purest code on the master branch and maintain an always runnable source code, master branch is protected from any merge. Members tried their code in the local repo or at their own branch, the finest and the most stable code is chosen and pushed to the master branch. 

# Special Statement On Testing

We're confused by the requirement of whether or not to include specifically JUnit as a ***mandatory*** test approach and submit the test/ directory. We've tested every function ***manually*** during each sprint of constructing code. By "manually test", we comment and de-comment the test code block in the app/, and fully compile and run the game in the browser. We have been doing thisfrom the very beginning of the project and we feel OK with this approach. 

It is later claimed in the Q&A panel that somehow JUnit seems to be a mandatory test approach **but** we've almost finished the project. We will, however, add some JUnit test cases as required to demonstrate we **CAN** use JUnit as a test approach. But most of testing work will still happen in the main class in app/, and we will make you aware of how that happens.

# ITSD_CardGame Project Documentation
[Wiki URL for Syatem Design & Testing](https://stgit.dcs.gla.ac.uk/team-project-m/2020/it-team-project-wlygt/itsd_cardgame/-/wikis/Project-Wiki-Home-Page)


## System Design

Please check the project wiki for brief information about how we modified the system.

[System Design URL](https://stgit.dcs.gla.ac.uk/team-project-m/2020/it-team-project-wlygt/itsd_cardgame/-/wikis/System-Design-Docs)

## Testing

Please check the project wiki for brief information about how we tested the system.

[Test Case URL](https://stgit.dcs.gla.ac.uk/team-project-m/2020/it-team-project-wlygt/itsd_cardgame/-/wikis/uploads/748e38be94c40b44d7655c4edecbab30/Test_Cases_En.pdf)


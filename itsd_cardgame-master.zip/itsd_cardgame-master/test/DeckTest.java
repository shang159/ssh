import org.junit.Test;

import structures.DeckGenerator;
import structures.basic.Deck;
import structures.basic.Hand;

/**
 * ! SPECIAL STATEMENT ON TESTING
 * 
 * (you can find the full statement in the readme.md)
 * 
 * This test case is a simple demonstration that we CAN write external
 * test cases, but please note that we've conducted testing through sprints
 * and the test happened mainly in the app/ folder.
 * */
public class DeckTest {

	public DeckTest() {
		// TODO Auto-generated constructor stub
	}

	@Test
	/**the test check whether the shared card is properly added*/
	public void DeckGeneratorTest() {
		Deck[] decks = DeckGenerator.generateDecks(false);
		
		while (decks[0].hasCard()) {
			System.out.printf("%s, remains %d\t\n", decks[0].popCard(), decks[0].getRemainingCardsNum());
		}
		
		while (decks[1].hasCard()) {
			System.out.printf("%s, remains %d\t\n", decks[1].popCard(), decks[1].getRemainingCardsNum());
		}
	}
}
